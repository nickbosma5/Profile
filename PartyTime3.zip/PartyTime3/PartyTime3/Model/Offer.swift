//
//  OfferCellData.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/18/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

class Offer{
    var offerID: String
    var itemID: String
    var startDate: String
    var endDate: String
    var location: String
    var notes: String
    var renterID: String
    var loanerID: String
    
    
    
    init(offerID: String, itemID: String, startDate: String, endDate: String, location: String, notes: String, renterID: String, loanerID: String) {
        self.offerID = offerID
        self.itemID = itemID
        self.startDate = startDate
        self.endDate = endDate
        self.location = location
        self.notes = notes
        self.renterID = renterID
        self.loanerID = loanerID
    }
}
