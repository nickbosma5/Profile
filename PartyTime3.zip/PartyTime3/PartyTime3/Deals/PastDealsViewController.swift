//
//  PastDealsViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/23/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class PastDealsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        super.viewDidLoad()
        tableView.dataSource = self
        tableView.rowHeight = 130
        
    }
    
    
}

extension PastDealsViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CompletedDealsCell", for: indexPath)
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print("hello")
    }
}

