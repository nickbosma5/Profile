//
//  AddNotesViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/22/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase

class AddNotesViewController: UIViewController {
    @IBOutlet var notesTextView: UITextView!
    @IBOutlet var saveButton: UIBarButtonItem!
    @IBOutlet var cancelButton: UIBarButtonItem!
    
    var notes = String()
    var itemID = String()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapG = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tapG)

    }
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func dismissKeyboard(){
        view.endEditing(true)
        self.resignFirstResponder()
        print("recieved")
    }

    @IBAction func saveTouched(_ sender: Any) {
        if self.notesTextView.text != self.notes {
            self.notes = self.notesTextView.text
            Database.database().reference().child("market").child(self.itemID).child("notes").setValue(self.notes)
            dismiss(animated: true, completion: nil)
            
        }
        else{
            dismiss(animated: true, completion: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
