//
//  FinalAddItemViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/5/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import YPImagePicker
import Firebase

class FinalAddItemViewController: UIViewController, UIGestureRecognizerDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UITextFieldDelegate, UICollectionViewDelegateFlowLayout, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func hideKeyboard(){
        let Tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        Tap.delegate = self
        view.addGestureRecognizer(Tap)
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
        self.pickerView.isHidden = true
        self.pickerViewButton.isHidden = true
        self.pickerViewBar.isHidden = true
        self.pickerViewButton.isEnabled = false
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickViewOption == "category"{
            return data.count
        }
        else if self.pickViewOption == "tag"{
            return tagData.count
        }
        else if self.pickViewOption == "color"{
            return colorData.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if self.pickViewOption == "category"{
            return data[row]
        }
        else if self.pickViewOption == "tag"{
            return tagData[row]
        }
        else if self.pickViewOption == "color"{
            return colorData[row]
        }
        return ""
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.photoCollectionView{
            return photos.count
        }
        else{
            return tags.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.photoCollectionView {
            return CGSize(width: 100, height: 100)
        }
        else{
            return CGSize(width: 70, height: 40)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.photoCollectionView{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "test", for: indexPath) as! photoCollectionViewCell
            cell.imageView.image = self.photos[indexPath.row]
            cell.imageView.isUserInteractionEnabled = true
            return cell
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "test", for: indexPath) as! tagCollectionViewCell
            cell.tagTextView.text = tags[indexPath.row]
            cell.tagTextView.allowsEditingTextAttributes = false
            cell.isUserInteractionEnabled = true
            return cell
            
        }
    }
    
    @IBOutlet weak var addItemButton: UIBarButtonItem!
    @IBOutlet weak var addPictureButton: UIButton!
    @IBOutlet weak var photoCollectionView: UICollectionView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var typeTextField: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    @IBOutlet weak var rentalTextView: UITextView!
    @IBOutlet weak var replacementTextView: UITextView!
    @IBOutlet weak var tagCollectionView: UICollectionView!
    @IBOutlet weak var colorsCollectionView: UICollectionView!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var pickerViewBar: UIView!
    @IBOutlet weak var pickerViewButton: UIButton!
   
    @IBOutlet weak var replacementStepper: UIStepper!
    @IBOutlet weak var dailyStepper: UIStepper!
    
    var userID = ""
    let tagController = tagCollectionViewController()
    let colorController = ColorCollectionViewController()
    var pickViewOption = ""
    var photos = [UIImage]()
    var tags = [String]()
    var colors = [String]()
    let colorData = ["white", "purple", "black", "orange", "yellow", "green"]
    let data = ["Accessory", "Costume", "Dress", "Jacket", "Jersey", "Pants", "Prop", "Romper", "Shoes", "Shorts", "Skirt", "Top", "Other"]
    let tagData = ["Active-wear", "Animal", "Baseball", "Basketball", "Beach", "Christmas", "Medical", "Fancy", "Flannel", "Football", "Formal", "Glasses", "Golf", "Halloween", "Hat", "Hockey", "Jungle", "Mask", "Movie", "Neon", "Office", "Outerspace", "Pajamas", "Patriotic", "Retro", "Skiing", "Soccer", "Tennis", "Toga", "Western", "Winter"]
    let imagePicker = YPImagePicker()
    var photo_urls = [String]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        if Auth.auth().currentUser != nil{
            self.userID = (Auth.auth().currentUser?.uid)!
        }
        self.nameTextField.attributedPlaceholder = NSAttributedString(string: "Name",
                                                                                 attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        self.descriptionTextField.attributedPlaceholder = NSAttributedString(string: "Description",
                                                                             attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        self.typeTextField.attributedPlaceholder = NSAttributedString(string: "Type",
                                                                      attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        self.hideKeyboard()
        self.tagCollectionView.delegate = tagController
        self.tagCollectionView.dataSource = tagController
        self.colorsCollectionView.delegate = colorController
        self.colorsCollectionView.dataSource = colorController
        self.pickerViewButton.isEnabled = false
        self.pickerViewButton.isHidden = true
        self.pickerViewBar.isHidden = true
        self.pickerView.isHidden = true
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        self.photoCollectionView.dataSource = self
        self.photoCollectionView.delegate = self
        self.typeTextField.delegate = self
        self.nameTextField.delegate = self
        self.descriptionTextField.delegate = self
        [self.typeTextField, self.nameTextField, self.descriptionTextField].forEach({ $0?.addTarget(self, action: #selector(editingChanged), for: .editingChanged)})
        
        self.addItemButton.isEnabled = false
        self.hideKeyboard()
        // Do any additional setup after loading the view.
    }
    
    @objc func editingChanged(_ textField: UITextField) {
        if textField.text?.characters.count == 1 {
            if textField.text?.characters.first == " " {
                textField.text = ""
                return
            }
        }
        let nameCount = self.nameTextField.text?.count
        let typeCount = self.typeTextField.text?.count
        let descripCount = self.descriptionTextField.text?.count
        if nameCount == 0 || typeCount == 0 || self.photos.count == 0{
            self.addItemButton.isEnabled = false
        }
            
        else{
            addItemButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
            self.addItemButton.isEnabled = true
        }
    }
    
    @IBAction func doneTouched(_ sender: Any) {
        let int = self.pickerView.selectedRow(inComponent: 0)
        if self.pickViewOption == "category" {
            self.typeTextField.text = data[int]
        }
        else if self.pickViewOption == "tag"{
            self.tagController.tags.append(tagData[int])
            self.tagCollectionView.reloadData()
            self.tagCollectionView.collectionViewLayout.invalidateLayout()
        }
        else if self.pickViewOption == "color"{
            self.colorController.colorStrings.append(colorData[int])
            self.colorsCollectionView.reloadData()
        }
        self.pickerView.isHidden = true
        self.pickerViewButton.isEnabled = false
        self.pickerViewButton.isHidden = true
        self.pickerViewButton.isHidden = true
        self.pickerViewBar.isHidden = true
    
        editingChanged(self.typeTextField)
    }
    
    @IBAction func rentalFeeChanged(_ sender: Any) {
        self.rentalTextView.text = "$" + String(dailyStepper.value) + "0"
    }
    
    @IBAction func replacementValueChanged(_ sender: Any) {
        self.replacementTextView.text = "$" + String(replacementStepper.value) + "0"
    }
    
    @IBAction func nameEditBegin(_ sender: Any) {
        self.nameTextField.becomeFirstResponder()
    }
    
    @IBAction func nameEditEnd(_ sender: Any) {
        self.nameTextField.resignFirstResponder()
    }
    
    @IBAction func addTagTouched(_ sender: Any) {
        self.pickViewOption = "tag"
        self.pickerView.reloadAllComponents()
        self.pickerView.isHidden = false
        self.pickerViewButton.isHidden = false
        self.pickerViewButton.isEnabled = true
        self.pickerViewBar.isHidden = false
    }
    
    @IBAction func minusTagTouched(_ sender: Any) {
        if self.tagController.tags.count != 0{
            self.tagController.tags.remove(at: self.tagController.tags.count - 1)
            self.tagCollectionView.reloadData()
        }
    }
    
    @IBAction func addColorTouched(_ sender: Any) {
        self.pickViewOption = "color"
        self.pickerView.reloadAllComponents()
        self.pickerView.isHidden = false
        self.pickerViewButton.isHidden = false
        self.pickerViewButton.isEnabled = true
        self.pickerViewBar.isHidden = false
    }
    
    @IBAction func minusColorTouched(_ sender: Any) {
        if self.colorController.colorStrings.count != 0{
            self.colorController.colorStrings.remove(at: self.colorController.colorStrings.count - 1)
            self.colorsCollectionView.reloadData()
        }
    }
    
    @IBAction func typeEditBegin(_ sender: Any) {
        self.pickViewOption = "category"
        self.dismissKeyboard()
        self.typeTextField.resignFirstResponder()
        self.pickerView.reloadAllComponents()
        self.pickerView.isHidden = false
        self.pickerViewBar.isHidden = false
        self.pickerViewButton.isHidden = false
        self.pickerViewButton.isEnabled = true
    }
    
    @IBAction func descripEditBegin(_ sender: Any) {
        self.descriptionTextField.becomeFirstResponder()
    }
    
    @IBAction func descripEditEnd(_ sender: Any) {
        self.descriptionTextField.resignFirstResponder()
    }
    
    @IBAction func typeEditEnd(_ sender: Any) {
        print("type edit end")
    }
    
    
    @objc func DismissItemList(){
        self.pickerView.isHidden = true
        self.pickerViewButton.isEnabled = false
        self.pickerViewButton.isHidden = true
        self.pickerViewBar.isHidden = true
    }
    
    @IBAction func addPhotoTouched(_ sender: Any) {
        let imagePicker = YPImagePicker()
        imagePicker.delegate = self
        imagePicker.didFinishPicking { [unowned imagePicker] items, _ in
            if let photo = items.singlePhoto {
                self.photos.append(photo.image)
                print(self.photos.count)
                self.photoCollectionView.reloadData()
                //self.imageView.image = photo.image
                //self.addImageButton.isEnabled = false
                //self.addImageButton.isHidden = true
                
            }
            imagePicker.dismiss(animated: true, completion: nil)
        }
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage{
            print("added")
            self.photos.append(image)
            print(self.photos.count)
            self.photoCollectionView.reloadData()
        }
        print("added2")
        editingChanged(self.typeTextField)
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func addItemTouched(_ sender: Any) {
        var data = Data()
        let item_id = self.randomString(num: 20)
        var photoData = [Data]()
        let photo_count = self.photos.count
        for x in 0..<photo_count {
            data = photos[x].jpegData(compressionQuality: 1)!
            photoData.append(data)
        }
        
        
        let random = self.randomString(num: 20)
        let imageRef = Storage.storage().reference().child("itemImages").child(random)
        let uploadTask = imageRef.putData(photoData[0], metadata: nil) {(metadata, error) in
            guard let metadata = metadata else{
                print("error")
                return
            }
            print("uploaded")
            imageRef.downloadURL{ (url, error) in
                guard let downloadURL = url else{
                    print("error")
                    return
                }
                
                self.photo_urls.append(downloadURL.absoluteString)
                
                let item = NewItem(loanerID: self.userID, downloadURLs: self.photo_urls, ItemName: self.nameTextField.text!, category: self.typeTextField.text!, rentalRate: self.dailyStepper.value, replacementFee: self.replacementStepper.value, itemID: item_id, tags: self.tagController.tags, colors: self.colorController.colorStrings, descrip: self.descriptionTextField.text!)
                let DBitem = ["loanerID": item.loanerID, "type" : item.category, "downloadURL" : item.downloadURLs, "name" : item.ItemName, "rentalRate" : item.rentalRate, "replacementFee" : item.replacementFee, "tags" : self.tagController.tags, "colors" : self.colorController.colorStrings, "description" : item.descrip] as [String : Any]
                Database.database().reference().child("market/" + item.itemID).setValue(DBitem)
                
                Database.database().reference().child("users").child(self.userID).observeSingleEvent(of: .value, with: { (snapshot) in
                    // Get user value
                    let value = snapshot.value as? NSDictionary
                    var closet = value?["closet"] as? [String] ?? [""]
                    print(closet)
                    if closet[0] == "" {
                        closet[0] = item_id
                    }
                        
                    else{
                        closet.append(item_id)
                    }
                    self.uploadOtherPhotos(data: photoData, item_id: item_id)
                    Database.database().reference().child("users").child(self.userID).child("closet").setValue(closet)
                })
            }
        }
        
        
        dismiss(animated: true, completion: nil)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.photoCollectionView{
            self.photos.remove(at: indexPath.row)
            photoCollectionView.reloadData()
            return
        }
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if ((touch.view?.isDescendant(of: photoCollectionView))!){
            return false
        }
        else if ((touch.view?.isDescendant(of: tagCollectionView))!){
            return false
        }
        else{
            return true
        }
    }
    
    
    
    
    
    
    
    
    
    
    func uploadOtherPhotos(data: [Data], item_id: String){
        for x in 1..<self.photos.count{
            let random = self.randomString(num: 20)
            let imageRef = Storage.storage().reference().child("itemImages").child(random)
            /*let uploadTask = imageRef.putData(data[x], metadata: nil) {(metadata, error) in
                guard let metadata = metadata else{
                    print("error")
                    return
                }
                print("uploaded")
                imageRef.downloadURL{ (url, error) in
                    guard let downloadURL = url else{
                        print("error")
                        return
                    }
                    
                    self.photo_urls.append(downloadURL.absoluteString)
                    
                    Database.database().reference().child("market").child(item_id).observeSingleEvent(of: .value, with: { (snapshot) in
                        // Get user value
                        let value = snapshot.value as? NSDictionary
                        var downloadURLS = value?["downloadURL"] as! [String]
                        downloadURLS.append(downloadURL.absoluteString)
                        Database.database().reference().child("market").child(item_id).child("downloadURL").setValue(downloadURLS)
                    })
                }
            }*/
            Database.database().reference().child("market").child(item_id).observeSingleEvent(of: .value, with: { (snapshot) in
                // Get user value
                let value = snapshot.value as? NSDictionary
                var downloadURLS = value?["downloadURL"] as? [String] ?? []
                Database.database().reference().child("market").child(item_id).child("downloadURL").setValue(downloadURLS)
            })
        }
    }
    
    
    
    
}
