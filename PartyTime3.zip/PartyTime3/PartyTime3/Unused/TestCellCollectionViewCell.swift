//
//  TestCellCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/5/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class TestCellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var commentLabel: UITextView!
    @IBOutlet weak var captionLabel: UITextView!
    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.layer.cornerRadius = 6
        contentView.layer.masksToBounds = true
    }
    
    var photo: Photo? {
        didSet {
            if let photo = photo {
                imageView.image = photo.image
                captionLabel.text = photo.caption
                commentLabel.text = photo.comment
            }
        }
    }
    
}
