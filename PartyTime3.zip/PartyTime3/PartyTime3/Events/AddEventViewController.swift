//
//  AddEventViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/18/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import YPImagePicker

class AddEventViewController: UIViewController, UIGestureRecognizerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.allTags.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.allTags[row]
    }
    
    @IBOutlet var description2TextView: UITextView!
    @IBOutlet var dateButton: UIButton!
    var date = Date()
    var eventItem = [String: Any]()
    var photos = [UIImage]()
    var tags = [String]()
    let tagCVC = EventTagCollectionViewController()
    var allTags = ["Active-wear", "Animal", "Baseball", "Basketball", "Beach", "Christmas", "Medical", "Fancy", "Flannel", "Football", "Formal", "Glasses", "Golf", "Halloween", "Hat", "Hockey", "Jungle", "Mask", "Movie", "Neon", "Office", "Outerspace", "Pajamas", "Patriotic", "Retro", "Skiing", "Soccer", "Tennis", "Toga", "Western", "Winter"]
    @IBOutlet var doneButton: UIButton!
    @IBOutlet var pickerBar: UIView!
    @IBOutlet var datePickerView: UIDatePicker!
    @IBOutlet var privateSwitch: UISwitch!
    @IBOutlet var privateTextView: UITextView!
    @IBOutlet var publicTextView: UITextView!
    @IBOutlet var descriptionTextView: UITextView!
    @IBOutlet var dateTextView: UITextView!
    @IBOutlet var locationTextField: UITextField!
    @IBOutlet var eventTitleTextField: UITextField!
    @IBOutlet var eventImageView: UIImageView!
    @IBAction func dateTouched(_ sender: Any) {
        self.presentPicker()
    }
    @IBAction func doneTouched(_ sender: Any) {
        self.date = datePickerView.date
        self.setString(textView: self.dateTextView)
        self.hidePicker()
    }
    
    @IBOutlet var tagPickerDoneButton: UIButton!
    @IBOutlet var tagPickerBar: UIView!
    @IBOutlet var tagPickerView: UIPickerView!
    
    func hideTagPicker(){
        self.tagPickerBar.isHidden = true
        self.tagPickerDoneButton.isHidden = true
        self.tagPickerView.isHidden = true
    }
    func presentTagPicker(){
        self.tagPickerBar.isHidden = false
        self.tagPickerDoneButton.isHidden = false
        self.tagPickerView.isHidden = false
        self.tagPickerDoneButton.isEnabled = true
    }
    
    func hidePicker(){
        self.pickerBar.isHidden = true
        self.doneButton.isHidden = true
        self.datePickerView.isHidden = true
    }
    func presentPicker(){
        self.pickerBar.isHidden = false
        self.doneButton.isHidden = false
        self.datePickerView.isHidden = false
        self.doneButton.isEnabled = true
    }
    @IBAction func switchValueChanged(_ sender: Any) {
        if self.privateSwitch.isOn{
            self.publicTextView.textColor = UIColor.white
            self.privateTextView.textColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        }
        else{
            self.publicTextView.textColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
            self.privateTextView.textColor = UIColor.white
        }
    }
    
    func setString(textView: UITextView){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: self.date)
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = "EEE, MMMM d, ''yy @ h:mm a"
        let myStringafd = formatter.string(from: yourDate!)
        textView.text = myStringafd
    }
    
    @objc func receiveTap(){
        let imagePicker = YPImagePicker()
        imagePicker.delegate = self
        imagePicker.didFinishPicking { [unowned imagePicker] items, _ in
            if let photo = items.singlePhoto {
                self.photos.append(photo.image)
                print(self.photos.count)
                self.eventImageView.image = photo.image
                self.eventImageView.contentMode = .scaleAspectFill
                self.eventImageView.clipsToBounds = true
                //self.addImageButton.isEnabled = false
                //self.addImageButton.isHidden = true
                
            }
            
            imagePicker.dismiss(animated: true, completion: nil)
        }
        present(imagePicker, animated: true, completion: nil)
    }
    var loanerID = String()
    
    @IBOutlet var tagCollectionView: UICollectionView!
    
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        self.hidePicker()
        self.hideTagPicker()
        self.tagCollectionView.dataSource = tagCVC
        self.tagCollectionView.delegate = tagCVC
        self.tagPickerView.delegate = self
        self.tagPickerView.dataSource = self
        
        self.tagPickerView.backgroundColor = UIColor.white
        let tapG = UITapGestureRecognizer(target: self, action: #selector(receiveTap))
        self.eventImageView.addGestureRecognizer(tapG)
        self.datePickerView.backgroundColor = UIColor.white
        self.eventTitleTextField.attributedPlaceholder = NSAttributedString(string: "Event Title",
                                                                            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        self.locationTextField.attributedPlaceholder = NSAttributedString(string: "Location",
                                                                          attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        
        self.hideKeyboard()
        if let user = Auth.auth().currentUser{
            self.loanerID = user.uid
        }
        

    }
    func hideKeyboard(){
        let Tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        Tap.delegate = self
        view.addGestureRecognizer(Tap)
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
        self.resignFirstResponder()
        print("received")
    }
    
    @IBAction func CancelTouched(_ sender: Any) {
        print("cancelTouched")
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addTagTouched(_ sender: Any) {
        self.presentTagPicker()
        print(self.tagPickerView.numberOfRows(inComponent: 0))
    }
    
    @IBAction func tagDoneTouched(_ sender: Any) {
        let int = self.tagPickerView.selectedRow(inComponent: 0)
        print(int)
        self.tagCVC.tags.append(self.allTags[int])
        self.tagCollectionView.reloadData()
        self.hideTagPicker()
    }
    
    
    @IBAction func tagMinusTouched(_ sender: Any) {
        self.tagCVC.tags.remove(at: (self.tagCVC.tags.count - 1))
        self.tagCollectionView.reloadData()
    }
    
    
    @IBAction func addButtonTouched(_ sender: Any) {
        if self.eventTitleTextField.text?.count != 0 && self.locationTextField.text?.count != 0 && self.dateTextView.text?.count != 0{
            let photoData = self.eventImageView.image?.jpegData(compressionQuality: 1)
            
            let random = self.randomString(num: 20)
            let imageRef = Storage.storage().reference().child("eventPhotos").child(random)
            let uploadTask = imageRef.putData(photoData!, metadata: nil){(metadata, error) in
                guard let metadata = metadata else{
                    print("error")
                    return
                }
                imageRef.downloadURL{(url, error) in
                    guard let downloadURL = url else{
                        print("error")
                        return
                    }
                    if self.privateSwitch.isOn{
                        if self.tags.count != 0{
                            self.eventItem = ["title": self.eventTitleTextField.text, "location": self.locationTextField.text, "date": self.dateTextView.text, "accessibility": "private", "owner": self.loanerID, "description": self.description2TextView.text, "downloadURL": downloadURL.absoluteString, "tags": self.tags]
                        }
                        else{
                            self.eventItem = ["title": self.eventTitleTextField.text, "location": self.locationTextField.text, "date": self.dateTextView.text, "accessibility": "private", "owner": self.loanerID, "description": self.description2TextView.text, "downloadURL": downloadURL.absoluteString]
                        }
                        
                        
                    }
                    else{
                        if self.tags.count != 0{
                            self.eventItem = ["title": self.eventTitleTextField.text, "location": self.locationTextField.text, "date": self.dateTextView.text, "accessibility": "public", "owner": self.loanerID, "description": self.description2TextView.text, "downloadURL": downloadURL.absoluteString, "tags": self.tags]
                        }
                        else{
                            self.eventItem = ["title": self.eventTitleTextField.text, "location": self.locationTextField.text, "date": self.dateTextView.text, "accessibility": "public", "owner": self.loanerID, "description": self.description2TextView.text, "downloadURL": downloadURL.absoluteString]
                        }
                        
                    }
                    let random = self.randomString(num: 20)
                    
                Database.database().reference().child("events").child(random).setValue(self.eventItem)
                   
                }
                self.dismiss(animated: true, completion: nil)
            }
            
            
        }
        else{
            print("error")
        }
        
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if ((touch.view?.isDescendant(of: self.eventImageView))!){
            return false
        }
        else{
            
            return true
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.eventImageView.contentMode = .scaleAspectFill
        self.eventImageView.clipsToBounds = true
        print("changed")
        dismiss(animated: true, completion: nil)
        
    }
}

extension UIViewController{
    func randomString(num: Int) -> String {
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
        let len = UInt32(letters.length)
        
        var randomString = ""
        for _ in 0 ..< num{
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        return randomString
    }
}
