//
//  SearchPeopleViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/15/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
class SearchPeopleViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet var tableView: UITableView!
    var goingList = [String]()
    var invitedList = [String]()
    var infoList = [userInfo]()
    var eventID = String()
    var allUsers = [String]()
    var searchingList = [String]()
    var searching = false
    let dbref = Database.database().reference()
    
    
    @IBAction func doneTouched(_ sender: Any) {
        dbref.child("events").child(self.eventID).child("invited").setValue(self.invitedList)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return searchingList.count
        }
        else{
            return allUsers.count
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! SearchingTableViewCell
        if cell.statusTextView.text == "invited"{
            cell.statusTextView.text = ""
            for x in 0..<self.invitedList.count{
                if self.invitedList[x] == cell.userID{
                    self.invitedList.remove(at: x)
                    print("removed")
                    break
                }
            }
        }
        else if cell.statusTextView.text == ""{
            cell.statusTextView.text = "invited"
            cell.statusTextView.textColor = UIColor.yellow
            self.invitedList.append(cell.userID)
            print("added")
        }
        print(cell.userID)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SearchingTableViewCell
        var status = String()
        if searching{
            for x in 0..<self.infoList.count{
                if self.infoList[x].name == self.searchingList[indexPath.row]{
                    status = self.infoList[x].status
                    cell.userID = self.infoList[x].id
                    if status == "going"{
                        cell.statusTextView.textColor = UIColor.green
                    }
                    else if status == "invited"{
                        cell.statusTextView.textColor = UIColor.yellow
                    }
                }
            }
            cell.statusTextView.text = status
            cell.nameTextView.text = self.searchingList[indexPath.row]
        }
        else{
            for x in 0..<self.infoList.count{
                if self.infoList[x].name == self.allUsers[indexPath.row]{
                    status = self.infoList[x].status
                    cell.userID = self.infoList[x].id
                    if status == "going"{
                        cell.statusTextView.textColor = UIColor.green
                    }
                    else if status == "invited"{
                        cell.statusTextView.textColor = UIColor.yellow
                    }
                }
            }
            cell.statusTextView.text = status
            cell.nameTextView.text = self.allUsers[indexPath.row]
        }
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadLists()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.searchBar.delegate = self
        let textFieldInsideSearchBar = searchBar.value(forKey: "searchField") as? UITextField
        
        textFieldInsideSearchBar?.textColor = UIColor.white

    }
    
    func loadLists(){
        dbref.child("events").child(self.eventID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            let eventObject = snapshot.value as? NSDictionary
            self.goingList = eventObject?["going"] as? [String] ?? []
            self.invitedList = eventObject?["invited"] as? [String] ?? []
            self.loadUsers()
        })
    }
    
    func loadUsers(){
        if let user = Auth.auth().currentUser{
            dbref.child("users").observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                for users in snapshot.children.allObjects as! [DataSnapshot]{
                    let userObject = users.value as? [String: AnyObject]
                    let userID = users.key
                    if userID != user.uid{
                        let firstName = userObject?["FirstName"] as? String ?? ""
                        let lastName = userObject?["SecondName"] as? String ?? ""
                        let firstNameTrimmed = firstName.trimmingCharacters(in: .whitespaces)
                        let lastNameTrimmed = lastName.trimmingCharacters(in: .whitespaces)
                        let fullName = firstNameTrimmed + " " + lastNameTrimmed
                        //self.userDict.setValue(fullName, forKey: userID)
                        self.allUsers.append(fullName)
                        if self.goingList.contains(userID){
                            let newUserInfo = userInfo(name: fullName, id: userID, status: "going")
                            self.infoList.append(newUserInfo)
                        }
                        else if self.invitedList.contains(userID){
                            let newUserInfo = userInfo(name: fullName, id: userID, status: "invited")
                            self.infoList.append(newUserInfo)
                        }
                        else{
                            let newUserInfo = userInfo(name: fullName, id: userID, status: "")
                            self.infoList.append(newUserInfo)
                        }
                    }
                }
                self.tableView.reloadData()
            })
        }
    }
    
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchingList = allUsers.filter({$0.prefix(searchText.count) == searchText})
        searching = true
        tableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        tableView.reloadData()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
