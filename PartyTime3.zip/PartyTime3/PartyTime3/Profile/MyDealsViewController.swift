//
//  MyDealsViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/21/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase

class MyDealsViewController: UIViewController {
    @IBAction func DoneTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.rowHeight = 130
        self.loadItems()
        
    }
    
    var deals = [NSDictionary]()
    var photos = [String]()
    func loadItems(){
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("deals").child("past").observe(DataEventType.value, with: {(snapshot) in
                self.deals.removeAll()
                for deal in snapshot.children.allObjects as! [DataSnapshot]{
                    print("count")
                    let dealObject = deal.value as? NSDictionary
                    let loanerID = dealObject?["loanerID"] as? String ?? ""
                    let renterID = dealObject?["renterID"] as? String ?? ""
                    let itemID = dealObject?["itemID"] as? String ?? ""
                    Database.database().reference().child("market").child(itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                        let itemObject = snapshot.value as? NSDictionary
                        let itemName = itemObject?["name"] as? String ?? "error"
                        dealObject?.setValue(itemName, forKey: "itemName")
                        let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                        if downloadURL.count != 0{
                            self.photos.append(downloadURL[0])
                        }
                        if loanerID == user.uid || renterID == user.uid {
                            self.deals.append((dealObject)!)
                        }
                        
                        self.tableView.reloadData()
                    })
                }
            })
            Database.database().reference().child("deals").child("cancelled").observe(DataEventType.value, with: {(snapshot) in
                self.deals.removeAll()
                for deal in snapshot.children.allObjects as! [DataSnapshot]{
                    print("count")
                    let dealObject = deal.value as? NSDictionary
                    let loanerID = dealObject?["loanerID"] as? String ?? ""
                    let renterID = dealObject?["renterID"] as? String ?? ""
                    let itemID = dealObject?["itemID"] as? String ?? ""
                    Database.database().reference().child("market").child(itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                        let itemObject = snapshot.value as? NSDictionary
                        let itemName = itemObject?["name"] as? String ?? "error"
                        dealObject?.setValue(itemName, forKey: "itemName")
                        let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                        if downloadURL.count != 0{
                            self.photos.append(downloadURL[0])
                        }
                        if loanerID == user.uid || renterID == user.uid {
                            self.deals.append((dealObject)!)
                        }
                        
                        self.tableView.reloadData()
                    })
                }
            })

        }
    }

}

extension MyDealsViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return deals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MyDealsRentCell", for: indexPath) as! PastDealTableViewCell
        cell.nameTextView.text = self.deals[indexPath.row]["itemName"] as? String ?? ""
        if self.photos.count != 0{
            let urlString = self.photos[indexPath.row]
            let url = NSURL(string: urlString)!
            DispatchQueue.global(qos: .userInitiated).async {
                
                let imageData:NSData = NSData(contentsOf: url as URL)!
                
                
                DispatchQueue.main.async {
                    
                    let image = UIImage(data: imageData as Data)
                    cell.itemImageView.image = image
                    cell.itemImageView.contentMode = UIView.ContentMode.scaleAspectFill
                    cell.itemImageView.clipsToBounds = true
                }
            }
        }
        return cell
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print(indexPath.row)
    }
}
