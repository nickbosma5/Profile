//
//  MarketItem2ViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/24/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import AnimatedCollectionViewLayout
import Firebase

class MarketItem2ViewController: UIViewController {
    @IBOutlet weak var picturePriceView: UITextView!
    @IBOutlet weak var itemNameTextView: UITextView!
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var typeTextView: UITextView!
    @IBOutlet weak var tagsTextView: UITextView!
    @IBOutlet weak var replacementFeeTextView: UITextView!
    @IBOutlet var damageCollectionView: UICollectionView!
    @IBOutlet var offerButton: UIButton!
    @IBAction func doneTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func offerTouched(_ sender: Any) {
        if let user = Auth.auth().currentUser{
            if self.loanerID == user.uid{
                let alert = UIAlertController(title: "Error", message: "Cannot make offer on own item", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                alert.addAction(okAction)
                self.present(alert, animated: true, completion: nil)
            }
            else{
                let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
                let nextVC = storyboard.instantiateViewController(withIdentifier: "newOffer") as! MakeOfferViewController
                
                nextVC.loanerID = self.loanerID
                nextVC.itemID = self.itemID
                nextVC.replacementFee = self.replacementRate
                nextVC.dailyRate = self.rentalRate
                present(nextVC, animated: true, completion: nil)
            }
            
        }
        
    }
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageView: UIImageView!
    var itemName = String()
    var itemID = ""
    var photos = [String]()
    var loanerID = ""
    var rentalRate = 0.0
    var replacementRate = 0.0
    
    let damageController = DamagesCollectionViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.damageCollectionView.dataSource = self.damageController
        self.damageCollectionView.delegate = self.damageController
        
        let userID = Auth.auth().currentUser?.uid
        Database.database().reference().child("market").child(itemID).observeSingleEvent(of: .value, with: {(snapshot) in
            let value = snapshot.value as? NSDictionary
            self.photos = value?["downloadURL"] as? [String] ?? []
            let loanerID = value?["loanerID"] as? String ?? ""
            self.loanerID = loanerID
            print("asdhf;asfhasdhf;asdsaldfjas;fjads;f")
            print(self.loanerID)
            let itemName = value?["name"] as? String ?? "name"
            let type = value?["type"] as? String ?? "type"
            let rentalRate = value?["rentalRate"] as? Double ?? 0.00
            let replacementFee = value?["replacementFee"] as? Double ?? 0.00
            let tags = value?["tags"] as? [String] ?? []
            let colors = value?["colors"] as? [String] ?? []
            
            self.damageController.photoStrings = self.photos
            self.damageCollectionView.reloadData()
            self.replacementRate = replacementFee
            self.rentalRate = rentalRate
            if self.imageView.image == nil{
                let url = URL(string: self.photos[0])
                self.imageView.load(url: url!)
            }
            let description = value?["description"] as? String ?? ""
            
            self.picturePriceView.text = "$" + String(rentalRate) + "0"
            var tagString = ""
            for x in 0..<tags.count{
                tagString = tagString + tags[x] + " "
            }
            
            self.tagsTextView.text = tagString
            self.itemNameTextView.text = itemName
            self.typeTextView.text = (type)
            self.replacementFeeTextView.text = ("$" + String(replacementFee))
            self.descriptionTextView.text = description
            
            
        })
 
        var frame = self.descriptionTextView.frame
        print(self.descriptionTextView.contentSize.height)
        frame.size.height = self.descriptionTextView.contentSize.height
        self.descriptionTextView.frame = frame
        
    }
    

    

}
