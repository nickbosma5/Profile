//
//  TestViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/7/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import CollectionKit

class TestViewController: UIViewController {
    let photos = Photo.allPhotos()
    

    @IBOutlet weak var collectionView: CollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let dataSource = ArrayDataSource(data: [1, 2, 3, 4])
        let viewSource = ClosureViewSource(viewUpdater: { (view: UIImageView, data: Int, index: Int) in
            view.backgroundColor = .red
            
            

            view.contentMode = UIImageView.ContentMode.scaleAspectFill
            view.layer.masksToBounds = true
            view.image = self.photos[index].image
            
            
            
        })
        
        let sizeSource = { (index: Int, data: Int, collectionSize: CGSize) -> CGSize in
            return CGSize(width: self.photos[index].image.size.width, height: self.photos[index].image.size.height)
        }
        let provider = BasicProvider(
            dataSource: dataSource,
            viewSource: viewSource,
            sizeSource: sizeSource
        )
        
        //lastly assign this provider to the collectionView to display the content
        collectionView.provider = provider
        dataSource.data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        provider.layout = WaterfallLayout(columns: 2, spacing: 10)
    }
    

}
