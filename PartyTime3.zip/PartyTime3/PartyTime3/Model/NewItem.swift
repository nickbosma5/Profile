//
//  NewItem.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/15/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

class NewItem{
    var loanerID: String
    var downloadURLs: [String]
    var ItemName: String
    var category: String
    var rentalRate: Double
    var replacementFee: Double
    var itemID: String
    var tags: [String]
    var colors: [String]
    var descrip: String

    
    init(loanerID: String, downloadURLs: [String], ItemName: String, category: String, rentalRate: Double, replacementFee: Double, itemID: String, tags: [String], colors: [String], descrip: String) {
        self.downloadURLs = downloadURLs
        self.ItemName = ItemName
        self.category = category
        self.rentalRate = rentalRate
        self.replacementFee = replacementFee
        self.itemID = itemID
        self.tags = tags
        self.colors = colors
        self.descrip = descrip
        self.loanerID = loanerID
    }
    
    func randomString(num: Int) -> String {
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
        let len = UInt32(letters.length)
        
        var randomString = ""
        for _ in 0 ..< num{
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        return randomString
    }
}

