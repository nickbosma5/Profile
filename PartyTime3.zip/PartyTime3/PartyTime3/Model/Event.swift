//
//  Event.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/23/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

class Event{
    var owner: String
    var location: String
    var id: String
    var name: String
    var status: String
    
    
    init(ownerString: String, locationString: String, idString: String, nameString: String, status1: String) {
        owner = ownerString
        location = locationString
        id = idString
        name = nameString
        status = status1
    }
}
