//
//  DealsLayout.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/31/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit


class DealsLayout: UICollectionViewFlowLayout {
    
    override func prepare() {
        super.prepare()
        
        guard let cv = collectionView else {
            return
        }
        let availableWidth = cv.bounds.inset(by: cv.layoutMargins).size.width
        let minColumnWidth = CGFloat(300.0)
        let maxNumColumns = Int(availableWidth/minColumnWidth)
        
        let cellWidth = (availableWidth / CGFloat(maxNumColumns)).rounded(.down)
        
        self.itemSize = CGSize(width: cellWidth, height: 130)
        self.sectionInset = UIEdgeInsets(top:self.minimumInteritemSpacing, left: 0.0, bottom: 0.0, right: 0.0)
        self.sectionInsetReference = .fromSafeArea
        
    }
    
    
    

}
