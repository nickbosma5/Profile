//
//  EventsViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/23/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class EventsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if my_events_selected == 0{
            return events.count
        }
        else{
            return myEvents.count
        }
    }
    var my_events_selected =  1
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "eventItem") as! MarketItemViewController
        if my_events_selected == 0{
            nextVC.eventID = events[indexPath.row].id
            nextVC.status = events[indexPath.row].status
        }
        else{
            nextVC.eventID = myEvents[indexPath.row].id
            nextVC.status = myEvents[indexPath.row].status

        }
        nextVC.modalPresentationStyle = .overCurrentContext
        present(nextVC, animated: true, completion: nil)
        //let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //appDelegate.window!.rootViewController = nextVC
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if my_events_selected == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "findEventCell", for: indexPath) as! EventTableViewCell
            let event: Event
            event = events[indexPath.row]
            cell.idTextField.text = event.name
            cell.locationTextField.text = event.location
            cell.dateTextField.text = event.owner
            
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "myEventCell", for: indexPath) as! MyEventTableViewCell
            let event: Event
            event = myEvents[indexPath.row]
            if event.status == "going"{
                cell.statusTextField.text = "going"
                cell.statusTextField.textColor = UIColor.green
                
            }
            else if event.status == "owner"{
                cell.statusTextField.text = "owner"
                cell.statusTextField.textColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
            }
            else if event.status == "invited" {
                cell.statusTextField.text = "invited"
                cell.statusTextField.textColor = UIColor.yellow
            }
            else {
                print("error")
            }
            cell.idTextField.text = event.name
            cell.locationTextField.text = event.location
            cell.dateTextField.text = event.owner
            return cell

        }
        
        
    }
    
    

    @IBOutlet weak var MyEventsButton: UIButton!
    @IBOutlet weak var FindEventButton: UIButton!
    
    @IBAction func addEventTouched(_ sender: Any) {
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "addEvent")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window!.rootViewController = nextVC
    }
    
    @IBAction func FindEventsTouched(_ sender: Any) {
        my_events_selected = 0
        FindEventButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        MyEventsButton.tintColor = UIColor.lightGray
        pageCounter.currentPage = 0
        tableView.reloadData()
    }
    
    @IBAction func MyEventsTouched(_ sender: Any) {
        my_events_selected = 1
        FindEventButton.tintColor = UIColor.lightGray
        MyEventsButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        pageCounter.currentPage = 1
        tableView.reloadData()
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var pageCounter: UIPageControl!
    var events = [Event]()
    var myEvents = [Event]()
    
    override func viewDidLoad() {
        if let user = Auth.auth().currentUser{
            tableView.delegate = self
            tableView.dataSource = self
            tableView.rowHeight = 130
            FindEventButton.tintColor = UIColor.lightGray
            MyEventsButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
            
            
            
            Database.database().reference().child("events").observe(DataEventType.value, with: {(snapshot) in
                self.myEvents.removeAll()
                self.events.removeAll()
                print("removed all")
                print(self.myEvents.count)
                for events in snapshot.children.allObjects as! [DataSnapshot]{
                    print("entering")
                    let eventObject = events.value as? [String: AnyObject]
                    let owner = eventObject?["owner"] as? String ?? ""
                    let location = eventObject?["location"] as? String ?? ""
                    let name = eventObject?["title"] as? String ?? ""
                    let invited = eventObject?["invited"] as? [String] ?? []
                    let going = eventObject?["going"] as? [String] ?? []
                    let id = events.key
                    let access = eventObject?["accessibility"] as? String ?? ""
                    Database.database().reference().child("users").child(owner).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                        let userObject = snapshot.value as? NSDictionary
                        let ownerString = userObject?["FirstName"] as? String ?? ""
                        let ownerString2 = userObject?["SecondName"] as? String ?? ""
                        let ownerName = ownerString + ownerString2
                        
                        if owner == user.uid{
                            let event = Event(ownerString: ownerName, locationString: location, idString: id, nameString: name, status1: "owner")
                            self.myEvents.append(event)
                        }
                        else if invited.contains(user.uid){
                            let event = Event(ownerString: ownerName, locationString: location, idString: id, nameString: name, status1: "invited")
                            self.myEvents.append(event)
                            
                        }
                        else if going.contains(user.uid){
                            let event = Event(ownerString: ownerName, locationString: location, idString: id, nameString: name, status1: "going")
                            self.myEvents.append(event)
                        }
                        else if access == "public"{
                            let event = Event(ownerString: ownerName, locationString: location, idString: id, nameString: name, status1: "none")
                            self.events.append(event)
                        }
                        else{
                            print("\(id) is private and you are not invited, not added")
                        }
                        self.tableView.reloadData()
                        print(self.myEvents)
                    })
                    
                }
                self.tableView.reloadData()
            })
        }
        
    
    }
}


