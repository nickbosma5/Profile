//
//  tagCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/18/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class tagCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var tagTextView: UITextView!
    
}
