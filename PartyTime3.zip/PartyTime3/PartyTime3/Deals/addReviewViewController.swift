//
//  addReviewViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/23/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import Cosmos

class addReviewViewController: UIViewController {
    var dealID = String()
    var renterID = String()
    var loanerID = String()
    var otherUserID = String()
    var dealObject = [String:Any]()
    var upcomingORongoing = String()
    
    
    
    @IBOutlet var commentsTextField: UITextView!
    @IBOutlet var commentsTextView: UITextView!
    @IBOutlet var ratingView: CosmosView!
    @IBOutlet var howWouldYouTextView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapG = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tapG)
        if let user = Auth.auth().currentUser{
            if user.uid == self.renterID{
                self.otherUserID = self.loanerID
            }
            else{
                self.otherUserID = self.renterID
            }
        }
        // Do any additional setup after loading the view.
    }
    
    @objc func dismissKeyboard(){
        self.view.endEditing(true)
        self.resignFirstResponder()
        print("received")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func submitTouched(_ sender: Any) {
        let random = self.randomString(num: 20)
        var reviewObject = [String:Any]()
        let comment = self.commentsTextField.text ?? ""
        let rating = self.ratingView.rating
        reviewObject = ["comment" : comment, "rating" : rating]
        Database.database().reference().child("users").child(self.otherUserID).child("reviews").child(random).setValue(reviewObject)
        print("success")
        if self.upcomingORongoing == "upcoming"{
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                self.dealObject = snapshot.value as? [String:Any] ?? [:]
                Database.database().reference().child("deals").child("upcoming").child(self.dealID).removeValue()
                print(self.dealID)
                Database.database().reference().child("deals").child("cancelled").child(self.dealID).setValue(self.dealObject)
                Database.database().reference().child("users").child(self.dealObject["renterID"] as! String).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    var pastDeals = userObject?["pastDeals"] as? [String] ?? []
                    pastDeals.append(self.dealID)
                    Database.database().reference().child("users").child(self.dealObject["renterID"] as! String).child("pastDeals").setValue(pastDeals)
                })
                Database.database().reference().child("users").child(self.dealObject["loanerID"] as! String).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    var pastDeals = userObject?["pastDeals"] as? [String] ?? []
                    pastDeals.append(self.dealID)
                    Database.database().reference().child("users").child(self.dealObject["loanerID"] as! String).child("pastDeals").setValue(pastDeals)
                })
                self.dismiss(animated: true, completion: nil)
            })
        }
        else{
            Database.database().reference().child("deals").child("ongoing").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                self.dealObject = snapshot.value as? [String:Any] ?? [:]
                Database.database().reference().child("deals").child("ongoing").child(self.dealID).removeValue()
                print(self.dealID)
                Database.database().reference().child("deals").child("past").child(self.dealID).setValue(self.dealObject)
                Database.database().reference().child("users").child(self.renterID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    var pastDeals = userObject?["pastDeals"] as? [String] ?? []
                    pastDeals.append(self.dealID)
                    Database.database().reference().child("users").child(self.renterID).child("pastDeals").setValue(pastDeals)
                })
                Database.database().reference().child("users").child(self.loanerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    var pastDeals = userObject?["pastDeals"] as? [String] ?? []
                    pastDeals.append(self.dealID)
                    Database.database().reference().child("users").child(self.renterID).child("pastDeals").setValue(pastDeals)
                })
                let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
                let nextVC = storyboard.instantiateViewController(withIdentifier: "tabBar")
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window!.rootViewController = nextVC
            })
        }
        
    }
    
}
