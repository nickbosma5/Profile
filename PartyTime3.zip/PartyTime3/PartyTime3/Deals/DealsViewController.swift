//
//  DealsViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase




class DealsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var ongoingDeals = [activeDeal]()
    var upcomingDeals = [activeDeal]()
    var userObject = NSDictionary()
    var userID = String()
    var photoStrings = [String]()
    var completed_selected = false
    @IBOutlet weak var completedButton: UIButton!
    @IBOutlet weak var activeButton: UIButton!
    @IBOutlet weak var pageCounter: UIPageControl!
    
    @IBAction func completedTouched(_ sender: Any) {
        completed_selected = true
        completedButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        activeButton.tintColor = UIColor.lightGray
        pageCounter.currentPage = 1
        self.load_active_deals()
        tableView.reloadData()
    }
    @IBAction func activeTouched(_ sender: Any) {
        completed_selected = false
        completedButton.tintColor = UIColor.lightGray
        activeButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        pageCounter.currentPage = 0
        self.load_active_deals()
        tableView.reloadData()
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if completed_selected == true {
            return ongoingDeals.count
        }
        else{
            print("active deals tableview")
            print(upcomingDeals)
            return upcomingDeals.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if completed_selected == true{
            let cell = tableView.dequeueReusableCell(withIdentifier: "test", for: indexPath) as! DealTableViewCell
            let deal: activeDeal
            if self.photoStrings.count != 0{
                print("entered")
                let urlString = self.photoStrings[indexPath.row]
                let url = NSURL(string: urlString)!
                DispatchQueue.global(qos: .userInitiated).async {
                    
                    let imageData:NSData = NSData(contentsOf: url as URL)!
                    
                    
                    DispatchQueue.main.async {
                        
                        let image = UIImage(data: imageData as Data)
                        cell.itemImageView.image = image
                        cell.itemImageView.contentMode = UIView.ContentMode.scaleAspectFill
                        cell.itemImageView.clipsToBounds = true
                    }
                }
            }
            if ongoingDeals.count != 0{
                deal = ongoingDeals[indexPath.row]
                cell.nameTextView.text = deal.itemId
                cell.dateTextView.text = (deal.startDate) + " - " + (deal.endDate)
                cell.totalTextView.text = "$"
                cell.ratingView.rating = 5.0
            }
            
            
            
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "testActive", for: indexPath) as! ActiveDealTableViewCell
            let deal: activeDeal
            if self.photoStrings.count != 0{
                print("entered")
                let urlString = self.photoStrings[indexPath.row]
                let url = NSURL(string: urlString)!
                DispatchQueue.global(qos: .userInitiated).async {
                    
                    let imageData:NSData = NSData(contentsOf: url as URL)!
                    
                    
                    DispatchQueue.main.async {
                        
                        let image = UIImage(data: imageData as Data)
                        cell.itemImageView.image = image
                        cell.itemImageView.contentMode = UIView.ContentMode.scaleAspectFill
                        cell.itemImageView.clipsToBounds = true
                    }
                }
            }
            if upcomingDeals.count != 0{
                deal = upcomingDeals[indexPath.row]
                cell.itemNameTextView.text = deal.itemId
                cell.returnDateTextView.text = deal.endDate
                cell.returnTimeTextView.text = "stuff"
                cell.startDateTextView.text = deal.startDate
            }
            
            
            
            
            
            return cell
        }

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 130
        completedButton.tintColor = UIColor.lightGray
        activeButton.tintColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        //load_completed_deals()
        load_active_deals()

        

        // Do any additional setup after loading the view.
    }
    func load_active_deals(){
        let uid = Auth.auth().currentUser?.uid
        print(1)
        Database.database().reference().child("users").child(uid!).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            
            let userObject = snapshot.value as? NSDictionary
            let upcomingDeals = userObject?["upcomingDeals"] as? [String] ?? []
            let ongoingDeals = userObject?["ongoingDeals"] as? [String] ?? []
            self.ongoingDeals.removeAll()
            self.upcomingDeals.removeAll()
            
            print(2)
            Database.database().reference().child("deals").child("upcoming").observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                for deal in snapshot.children.allObjects as! [DataSnapshot]{
                    if upcomingDeals.contains(deal.key){
                        let dealObject = deal.value as? [String: AnyObject]
                        let startDate = dealObject?["startDate"] as? String ?? ""
                        let endDate = dealObject?["endDate"] as? String ?? ""
                        let offerID = deal.key
                        let itemID = dealObject?["itemID"] as? String ?? ""
                        let loanerID = dealObject?["loanerID"] as? String ?? ""
                        let renterID = dealObject?["renterID"] as? String ?? ""
                        print(itemID)
                        print(3)
                        print("\(itemID) = itemID")
                        Database.database().reference().child("market").child(itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                            print(3)
                            let itemObject = snapshot.value as? [String: AnyObject]
                            let name = itemObject?["name"] as? String ?? ""
                            let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                            if downloadURL.count != 0{
                                self.photoStrings.append(downloadURL[0])
                            }
                            let rentalRate = itemObject?["rentalRate"] as? Double ?? 0.0
                            let newDeal = activeDeal(dealID: offerID, startDate: startDate, itemId: name, rentalRate: rentalRate, endDate: endDate, loanerID: loanerID, renterID: renterID)
                            self.upcomingDeals.append(newDeal)
                            self.tableView.reloadData()
                            
                        })

                    }
                }

            })
            print(4)
            Database.database().reference().child("deals").child("ongoing").observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                for deal in snapshot.children.allObjects as! [DataSnapshot]{
                    if ongoingDeals.contains(deal.key){
                        let dealObject = deal.value as? NSDictionary
                        let startDate = dealObject?["startDate"] as? String ?? ""
                        let endDate = dealObject?["endDate"] as? String ?? ""
                        let offerID = deal.key
                        let itemID = dealObject?["itemID"] as? String ?? ""
                        let loanerID = dealObject?["loanerID"] as? String ?? ""
                        let renterID = dealObject?["renterID"] as? String ?? ""
                        print(5)
                        Database.database().reference().child("market").child(itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                            let itemObject = snapshot.value as? NSDictionary
                            let name = itemObject?["name"] as? String ?? ""
                            let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                            if downloadURL.count != 0{
                                self.photoStrings.append(downloadURL[0])
                            }
                            let rentalRate = itemObject?["rentalRate"] as? Double ?? 0.0
                            let newDeal = activeDeal(dealID: offerID, startDate: startDate, itemId: name, rentalRate: rentalRate, endDate: endDate, loanerID: loanerID, renterID: renterID)
                            self.ongoingDeals.append(newDeal)
                            self.tableView.reloadData()
                        })
                    }
                }
            })
        })
    }
    
    func load_completed_deals(){
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.completed_selected {
            let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
            let nextVC = storyboard.instantiateViewController(withIdentifier: "ongoingDeal") as! ongoingDealViewController
            nextVC.itemID = self.ongoingDeals[indexPath.row].itemId
            nextVC.offerID = self.ongoingDeals[indexPath.row].dealID
            nextVC.tableViewController = self
            
            self.present(nextVC, animated: true, completion: nil)
            let cell = tableView.cellForRow(at: indexPath) as! DealTableViewCell
            if cell.itemImageView.image != nil {
                nextVC.itemImageView.image = cell.itemImageView.image
            }
            
        
        }
        else{
            let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
            let nextVC = storyboard.instantiateViewController(withIdentifier: "activeDeal") as! activeDealViewController
            nextVC.dealID = self.upcomingDeals[indexPath.row].dealID
            nextVC.tableViewController = self
            self.present(nextVC, animated: true, completion: nil)
            let cell = tableView.cellForRow(at: indexPath) as! ActiveDealTableViewCell
            if cell.itemImageView.image != nil {
                nextVC.itemImageView.image = cell.itemImageView.image
            }
        }
        

        
    }
    /*
     

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
