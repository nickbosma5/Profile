//
//  ProfileViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
import Cosmos


class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    @IBOutlet weak var usernameTextView: UITextView!
    @IBAction func LogoutTapped(_ sender: Any) {
        try! Auth.auth().signOut()
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "SignIn")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window!.rootViewController = nextVC
        
    }
    
    @IBOutlet var ratingView: CosmosView!
    
    var userImageURL = ""
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var clickToEditButton: UIButton!
    @IBAction func choosePhotoSelected(_ sender: Any) {
        imagePicker.delegate = self
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    var loadView = UIView()
    
    
    func addLoad(){
        self.loadView = UIView(frame: self.view.frame)
        let text = UITextView(frame: CGRect(x: 20, y: 90, width: 250, height: 100))
        text.center = self.view.center
        text.textAlignment = NSTextAlignment.center
        text.textColor = UIColor.white
        text.text = "Welcome to the party!"
        text.backgroundColor = UIColor.clear
        self.loadView.addSubview(text)
        self.loadView.isUserInteractionEnabled = false
        self.loadView.backgroundColor = UIColor.black
        self.view.addSubview(self.loadView)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadRating()
        
        addLoad()
        print("before")
        profileImage.layer.cornerRadius = profileImage.frame.height/2
        print("after")
        profileImage.clipsToBounds = true
        
        let dbRef = Database.database().reference()
        let userID = Auth.auth().currentUser?.uid
        
        
        
       dbRef.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            let downloadURL = value?["profImage"] as? String ?? ""
            let firstName = value?["FirstName"] as? String
            let lastName = value?["SecondName"] as? String
            let rating = value?["rating"] as? Double ?? 0.0
            let name = firstName! + " " + lastName!
            self.usernameTextView.text = name
            self.dismissLoading()
            if let imageURL = URL(string: downloadURL){
                self.profileImage.load(url: imageURL)
                self.clickToEditButton.isHidden = true
                self.clickToEditButton.isEnabled = false
            }
        self.loadView.isHidden = true
            
        }) { (error) in
            print(error.localizedDescription)
        }
        
        
    }
    func dismissLoading(){
        //self.loadingView.isHidden = true
        //self.loadingTextView.isHidden = true
    }
    
    let imagePicker = UIImagePickerController()
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage{
            var data = Data()
            data = image.jpegData(compressionQuality: 1)!
            print(data)
            
            let imageRef = Storage.storage().reference().child("images/" + randomString(num: 20))
            let _ = imageRef.putData(data, metadata: nil) { (metadata, error) in
                print("wow")
                guard let metadata = metadata else{
                    print("error uploading to firebase")
                    return
                }
                //let size = metadata.size
                imageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else{
                        return
                    }
                Database.database().reference().child("users").child((Auth.auth().currentUser?.uid)!).child("profImage").setValue(downloadURL.absoluteString)
                    print(downloadURL)
                }
            }
            profileImage.image = image
        }
        self.clickToEditButton.isHidden = true
        self.clickToEditButton.isEnabled = false
        dismiss(animated: true, completion: nil)
    }
    
    
    func loadRating(){
        var numReviews = 0.0
        var ratingTotal = 0.0
        var rating = Double()
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("users").child(user.uid).child("reviews").observe(DataEventType.value, with: {(snapshot) in
                for review in snapshot.children.allObjects as! [DataSnapshot]{
                    numReviews += 1
                    let reviewObject = review.value as? [String:Any]
                    let rating = reviewObject?["rating"] as? Double ?? 0.0
                    ratingTotal += rating
                    
                }
                if numReviews != 0 {
                    rating = ratingTotal / numReviews
                    self.ratingView.rating = rating
                }
                else{
                    self.ratingView.rating = 0
                }
                
            })
        }
    }
    
    
    
    
    

}
