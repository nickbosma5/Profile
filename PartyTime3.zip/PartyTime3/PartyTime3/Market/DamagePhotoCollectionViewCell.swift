//
//  DamagePhotoCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/18/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class DamagePhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    
}
