//
//  activeDeal.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

class activeDeal{
    var dealID: String
    var startDate: String
    var endDate: String
    var itemId: String
    var rentalRate: Double
    var loanerID: String
    var renterID: String
    
    
    init(dealID: String, startDate: String, itemId: String, rentalRate: Double, endDate: String, loanerID: String, renterID: String) {
        self.startDate = startDate
        self.itemId = itemId
        self.rentalRate = rentalRate
        self.dealID = dealID
        self.endDate = endDate
        self.loanerID = loanerID
        self.renterID = renterID
    }
}
