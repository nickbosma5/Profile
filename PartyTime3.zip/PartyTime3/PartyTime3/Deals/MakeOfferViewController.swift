//
//  MakeOfferViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/19/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase

class MakeOfferViewController: UIViewController, UIGestureRecognizerDelegate {
    var date = ""
    var renterID = ""
    var loanerID = ""
    var itemID = ""
    var dailyRate = 0.0
    var replacementFee = 0.0
    var startDate = Date()
    var endDate = Date()
    var offersReceived = [String]()
    @IBOutlet var daysTextField: UITextView!
    @IBOutlet var totalTextView: UITextView!
    
    
    @IBOutlet var notesTextField: UITextField!
    
    func hideKeyboard(){
        let Tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        Tap.delegate = self
        view.addGestureRecognizer(Tap)
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
    
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func changeStartTouched(_ sender: Any) {
        self.pullupPicker()
        self.date = "start"
    }
    
    @IBAction func endDateButtonClicked(_ sender: Any) {
        self.pullupPicker()
        self.date = "end"
    }
    
    
    @IBOutlet var pickerBar: UIView!
    @IBAction func pickerDone(_ sender: Any) {
        if self.date == "start"{
            setString(textView: self.startDateTextView)
            self.startDate = pickerView.date
            self.updateTextViews()
            
        }
        else if self.date == "end"{
            setString(textView: self.endDateTextView)
            self.endDate = pickerView.date
            self.updateTextViews()
        }
        self.dismissPicker()
    }
    func setString(textView: UITextView){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: self.pickerView.date)
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = "MM/dd/yyyy"
        let myStringafd = formatter.string(from: yourDate!)
        textView.text = myStringafd
    }
    
    
    
    
    @IBOutlet var pickerView: UIDatePicker!
    @IBOutlet var pickerDoneButton: UIButton!
    @IBOutlet var startDateTextView: UITextView!
    
    @IBOutlet var endDateTextView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dismissPicker()
        self.hideKeyboard()
        self.pickerView.backgroundColor = UIColor.white
        print(self.loanerID)
        print(self.dailyRate)
        print(self.replacementFee)
    }
    
    func dismissPicker(){
        self.pickerBar.isHidden = true
        self.pickerView.isHidden = true
        self.pickerDoneButton.isHidden = true
        self.pickerDoneButton.isEnabled = false
    }
    func pullupPicker(){
        self.pickerBar.isHidden = false
        self.pickerView.isHidden = false
        self.pickerDoneButton.isHidden = false
        self.pickerDoneButton.isEnabled = true
    }

    @IBAction func addOfferButtonTouched(_ sender: Any) {
        if self.startDateTextView.text.count != 0 && self.endDateTextView.text.count != 0 {
            let startString = self.startDateTextView.text
            let endString = self.endDateTextView.text
            
            let endArray = endString?.components(separatedBy: "/")
            let startArray = startString?.components(separatedBy: "/")
            
            if startArray![0] > endArray![0]{
                let alert = UIAlertController(title: "Error", message: "Dates not compatible", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                alert.addAction(okAction)
                self.present(alert, animated: true, completion: nil)
            }
                
                
            else if startArray![0] == endArray![0] {
                if startArray![1] >= endArray![1] {
                    let alert = UIAlertController(title: "Error", message: "Dates not compatible", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                    alert.addAction(okAction)
                    self.present(alert, animated: true, completion: nil)                }
                else{
                    self.renterID = (Auth.auth().currentUser?.uid)!
                    let offer = Offer(offerID: self.randomString(num: 20), itemID: self.itemID, startDate: startString!, endDate: endString!, location: "fakeLocation", notes: self.notesTextField.text ?? "", renterID: self.renterID, loanerID: self.loanerID)
                    let offerItem = ["itemID" : offer.itemID, "startDate": offer.startDate, "endDate": offer.endDate, "location": offer.location, "notes": offer.notes, "renterID": offer.renterID, "loanerID": offer.loanerID] as [String : Any]
                    
                    Database.database().reference().child("users").child(offer.loanerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                        let value = snapshot.value as? NSDictionary
                        var offersReceived = value?["offersReceived"] as? [String] ?? []
                        let upcomingDeals = value?["upcomingDeals"] as? [String] ?? []
                        if offersReceived.count == 0 && !upcomingDeals.contains(offer.offerID){
                            offersReceived = [offer.offerID]
                            self.offersReceived = offersReceived
                            Database.database().reference().child("users").child(offer.loanerID).child("offersReceived").setValue(self.offersReceived)
                            Database.database().reference().child("offers").child(offer.offerID).setValue(offerItem)
                        }
                        else{
                            if !offersReceived.contains(offer.offerID) && !upcomingDeals.contains(offer.offerID){
                                offersReceived.append(offer.offerID)
                                self.offersReceived = offersReceived
                                Database.database().reference().child("users").child(offer.loanerID).child("offersReceived").setValue(self.offersReceived)
                                Database.database().reference().child("offers").child(offer.offerID).setValue(offerItem)
                            }
                        }
                    })
                    Database.database().reference().child("users").child(offer.renterID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                        let value = snapshot.value as? NSDictionary
                        var offersPending = value?["offersPending"] as? [String] ?? []
                        let upcomingDeals = value?["upcomingDeals"] as? [String] ?? []
                        if offersPending.count == 0 && !upcomingDeals.contains(offer.offerID){
                            offersPending = [offer.offerID]
                            Database.database().reference().child("users").child(offer.renterID).child("offersPending").setValue(offersPending)
                        }
                        else{
                            if !offersPending.contains(offer.offerID) && !upcomingDeals.contains(offer.offerID){
                                offersPending.append(offer.offerID)
                                //self.offersReceived = offersReceived
                                Database.database().reference().child("users").child(offer.renterID).child("offersPending").setValue(offersPending)
                            }
                        }

                    })
                    
                }
            }
            else{
                print("accepted")
            }
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func updateTextViews(){
        let calendar = Calendar.current
        
        // Replace the hour (time) of both dates with 00:00
        let date1 = calendar.startOfDay(for: self.startDate)
        let date2 = calendar.startOfDay(for: self.endDate)
        
        let components = calendar.dateComponents([.day], from: date1, to: date2).day!
        
        self.daysTextField.text = "Days: \(components)"
        let money = self.dailyRate * Double(components ?? 0)
        self.totalTextView.text = "Total: $\(money)0"
    }
}


extension UIViewController{
    func stringToDate(string: String) -> Date{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM'/'dd'/'yyyy"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        let date = dateFormatter.date(from: string)!
        print(date)
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: date)
        let finalDate = calendar.date(from: components)
        return finalDate!
    }
    func dateToString(date: Date) -> String{
        let formatter = DateFormatter()
        let myString = formatter.string(from: date)
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = "mm-dd-yyyy"
        let myStringafd = formatter.string(from: yourDate!)
        return myStringafd
    }
    func calcDays(date: Date, date1: Date) -> Int{
        let calendar = Calendar.current
        let startDate = calendar.startOfDay(for: date)
        let endDate = calendar.startOfDay(for: date1)
        let components = calendar.dateComponents([.day], from: startDate, to: endDate).day!
        return components
    }
}
