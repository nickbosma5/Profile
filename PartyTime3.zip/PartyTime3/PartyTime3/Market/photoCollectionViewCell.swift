//
//  photoCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/17/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class photoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
}
