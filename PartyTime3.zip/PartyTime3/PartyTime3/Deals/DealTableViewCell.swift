//
//  DealTableViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Cosmos

class DealTableViewCell: UITableViewCell {
    @IBOutlet weak var nameTextView: UITextView!
    @IBOutlet weak var dateTextView: UITextView!
    @IBOutlet weak var totalTextView: UITextView!
    @IBOutlet weak var ratingView: CosmosView!
    @IBOutlet var itemImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
