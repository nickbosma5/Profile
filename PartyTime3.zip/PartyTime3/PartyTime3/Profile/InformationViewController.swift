//
//  InformationViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/17/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase


class InformationViewController: UIViewController {
    @IBOutlet weak var schoolTextView: UITextView!
    @IBOutlet weak var yearTextView: UITextView!
    @IBOutlet weak var emailTextField: UITextView!
    @IBOutlet weak var nameTextField: UITextView!
    @IBAction func DoneTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let userID = Auth.auth().currentUser?.uid

        Database.database().reference().child("users").observe(DataEventType.value, with: {(snapshot) in
            for events in snapshot.children.allObjects as! [DataSnapshot]{
                let id = events.key
                if id == userID {
                    let eventObject = events.value as? [String: AnyObject]
                    let name = (eventObject?["FirstName"] as! String) + " " + (eventObject?["SecondName"] as! String)
                    let school = eventObject?["school"] as! String
                    let year = eventObject?["year"] as! String
                    let email = eventObject?["Email"] as! String
                    self.schoolTextView.text = school
                    self.yearTextView.text = year
                    self.emailTextField.text = email
                    self.nameTextField.text = name
                }
                else{
                    print(events.key)
                }
            }
        })
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
