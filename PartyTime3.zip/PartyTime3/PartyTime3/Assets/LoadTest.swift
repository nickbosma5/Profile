//
//  LoadTest.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/8/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class LoadTest: UIImageView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}
