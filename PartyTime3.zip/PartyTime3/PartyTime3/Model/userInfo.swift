//
//  userInfo.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/16/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

class userInfo{
    var name: String
    var id: String
    var status: String
    
    init(name: String, id: String, status: String){
        self.name = name
        self.id = id
        self.status = status
    }
}
