//
//  SignUpViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase


class SignUpViewController: UIViewController, UIGestureRecognizerDelegate {
    @IBOutlet weak var FirstNameField: UITextField!
    @IBOutlet weak var SecondNameField: UITextField!
    @IBOutlet weak var EmailField: UITextField!
    @IBOutlet weak var PasswordField: UITextField!
    @IBAction func dismissOnClick(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func passChanged(_ sender: Any) {
        self.editingChanged(self.PasswordField)
    }
    @IBAction func emailChanged(_ sender: Any) {
        self.editingChanged(self.EmailField)
    }
    @IBAction func lastNameChanged(_ sender: Any) {
        self.editingChanged(self.SecondNameField)
    }
    @IBAction func nameChanged(_ sender: Any) {
        self.editingChanged(self.FirstNameField)
    }
    @IBAction func SignUpButtonTouched(_ sender: Any) {
        if (self.FirstNameField.text != nil && self.SecondNameField.text != nil && self.EmailField.text != nil && self.PasswordField.text != nil){
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let nextVC = storyboard.instantiateViewController(withIdentifier: "moreInfo") as! Signup2ViewController
            nextVC.firstName = self.FirstNameField.text!
            nextVC.lastName = self.SecondNameField.text!
            nextVC.email = self.EmailField.text!
            nextVC.password = self.PasswordField.text!
            
            present(nextVC, animated: true, completion: nil)
           // let appDelegate = UIApplication.shared.delegate as! AppDelegate
            //appDelegate.window!.rootViewController = nextVC
        }
        
    }
    
    func hideKeyboard(){
        let Tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        Tap.delegate = self
        view.addGestureRecognizer(Tap)
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
        
    }
    @objc func editingChanged(_ textField: UITextField) {
        if textField.text?.characters.count == 1 {
            if textField.text?.characters.first == " " {
                textField.text = ""
                return
            }
        }
        let FirstNameCount = FirstNameField.text?.count
        let LastNameCount = SecondNameField.text?.count
        let emailCount = EmailField.text?.count
        let passwordCount = PasswordField.text?.count
        if FirstNameCount == 0 || LastNameCount == 0 || emailCount == 0 || passwordCount == 0 {
            continueButton.isEnabled = false
        }
            
        else{
            continueButton.backgroundColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
            continueButton.isEnabled = true
        }
    }
    
    @IBOutlet weak var continueButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboard()
        self.continueButton.isEnabled = false
        self.continueButton.backgroundColor = UIColor.lightGray
        self.continueButton.tintColor = UIColor.clear
        EmailField.backgroundColor = UIColor.clear
        PasswordField.backgroundColor = UIColor.clear
        EmailField.textColor = UIColor.white
        PasswordField.textColor = UIColor.white
        FirstNameField.textColor = UIColor.white
        FirstNameField.backgroundColor = UIColor.clear
        SecondNameField.backgroundColor = UIColor.clear
        SecondNameField.textColor = UIColor.white
        
        EmailField.attributedPlaceholder = NSAttributedString(string: EmailField.placeholder!, attributes: [.foregroundColor: UIColor.lightGray])
        PasswordField.attributedPlaceholder = NSAttributedString(string: PasswordField.placeholder!, attributes: [.foregroundColor: UIColor.lightGray])
        FirstNameField.attributedPlaceholder = NSAttributedString(string: FirstNameField.placeholder!, attributes: [.foregroundColor: UIColor.lightGray])
        SecondNameField.attributedPlaceholder = NSAttributedString(string: SecondNameField.placeholder!, attributes: [.foregroundColor: UIColor.lightGray])
        
        /*let bottomLayer = CALayer()
        bottomLayer.frame = CGRect(x: 0, y: 29, width: 1000, height: 0.6)
        
        bottomLayer.backgroundColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor
        
        let bottomLayer1 = CALayer()
        bottomLayer1.frame = CGRect(x: 0, y: 29, width: 1000, height: 0.6)
        
        bottomLayer1.backgroundColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor
        
        let bottomLayer2 = CALayer()
        bottomLayer2.frame = CGRect(x: 0, y: 29, width: 1000, height: 0.6)
        
        bottomLayer2.backgroundColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor
        
        let bottomLayer3 = CALayer()
        bottomLayer3.frame = CGRect(x: 0, y: 29, width: 1000, height: 0.6)
        
        bottomLayer3.backgroundColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor
        
        EmailField.layer.addSublayer(bottomLayer)
        PasswordField.layer.addSublayer(bottomLayer1)
        FirstNameField.layer.addSublayer(bottomLayer2)
        SecondNameField.layer.addSublayer(bottomLayer3)*/

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
