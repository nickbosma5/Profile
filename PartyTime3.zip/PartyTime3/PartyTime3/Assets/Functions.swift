//
//  JumpToViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/11/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

/*
let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
let nextVC = storyboard.instantiateViewController(withIdentifier: "tabBar")
let appDelegate = UIApplication.shared.delegate as! AppDelegate
appDelegate.window!.rootViewController = nextVC
*/

/*
 func randomString(num: Int) -> String {
    let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    let len = UInt32(letters.length)
 
    var randomString = ""
    for _ in 0 ..< num{
        let rand = arc4random_uniform(len)
        var nextChar = letters.character(at: Int(rand))
        randomString += NSString(characters: &nextChar, length: 1) as String
    }
    return randomString
 }
 */

/*@IBAction func addImageTouched(_ sender: Any) {
    
    
    
    let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
    alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
        self.openCamera()
    }))
    
    alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
        self.openGallary()
    }))
    
    alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
    
    
    self.present(alert, animated: true, completion: nil)
}
let imagePicker = UIImagePickerController()


func openCamera()
{
    if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
    {
        imagePicker.delegate = self
        imagePicker.sourceType = UIImagePickerController.SourceType.camera
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    else
    {
        let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
func openGallary()
{
    imagePicker.delegate = self
    imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
    imagePicker.allowsEditing = true
    self.present(imagePicker, animated: true, completion: nil)
}

func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    if let image = info[.originalImage] as? UIImage{
        imageView.image = image
    }
    self.addImageButton.isHidden = true
    self.addImageButton.isEnabled = false
    dismiss(animated: true, completion: nil)
}
*/


/*UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)*/
