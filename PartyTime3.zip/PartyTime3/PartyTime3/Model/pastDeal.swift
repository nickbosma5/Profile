//
//  pastDeal.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import Foundation

class pastDeal{
    var dealID: String
    var dateOut: String
    var dateReturned: String
    var itemId: String
    var rating: Int
    var rentalRate: Int
    var receiptTotal: Float
    
    init(dealID: String, dateOut: String, dateReturned: String, itemId: String, rating: Int, rentalRate: Int, receiptTotal: Float) {
        self.dateOut = dateOut
        self.dateReturned = dateReturned
        self.itemId = itemId
        self.rating = rating
        self.rentalRate = rentalRate
        self.receiptTotal = receiptTotal
        self.dealID = dealID
    }
}
