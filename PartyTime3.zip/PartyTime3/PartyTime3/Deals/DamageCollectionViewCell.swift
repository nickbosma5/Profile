//
//  DamageCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/19/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class DamageCollectionViewCell: UICollectionViewCell {
    @IBOutlet var damagePhotoView: UIImageView!
    
}
