//
//  Signup2ViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/24/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
class Signup2ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    var data = ["Rhodes College", "University of Memphis", "Christian Brothers University"]
    var data2 = ["2019", "2020", "2021", "2022"]
    var selected = ""
    var firstName = ""
    var lastName = ""
    var email = ""
    var password = ""
    var schoolFilled = false
    var classFilled = false
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if self.selected == "class"{
            return self.data2.count
        }
        else{
            return self.data.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if self.selected == "class"{
            return data2[row]
        }
        else{
            return data[row]
        }
    }
    
    @IBOutlet weak var signUpButton: UIButton!
    @IBAction func signUpButtonTouched(_ sender: Any) {
        var ref: DatabaseReference!

        ref = Database.database().reference()
        
        
        Auth.auth().createUser(withEmail: self.email, password: self.password) { (authResult, error) in
            if error != nil {
                print(error!._code)
                self.handleError(error!)      // use the handleError method
                return
            }
            guard let user = authResult?.user else {
                print(error?.localizedDescription as Any)
                return
            }
            let uid = user.uid
            let usersReference = ref.child("users")
            let newUserReference = usersReference.child(uid)
            newUserReference.child("FirstName").setValue(self.firstName)
            newUserReference.child("SecondName").setValue(self.lastName)
            
            newUserReference.child("Email").setValue(self.email)
            newUserReference.child("school").setValue(self.schoolTextField.text)
            newUserReference.child("year").setValue(self.classTextField.text)
            //newUserReference.setValue(["secondname" : self.SecondNameField.text])
            // newUserReference.setValue(["Email" : self.EmailField.text])
            let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
            let profileVC = storyboard.instantiateViewController(withIdentifier: "tabBar")
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window!.rootViewController = profileVC
            
            
        }
    }
    @IBOutlet weak var doneButton: UIButton!
    @IBAction func doneButtonPressed(_ sender: Any) {
        let int = self.pickerView.selectedRow(inComponent: 0)
        if self.selected == "class"{
            if self.schoolFilled {
                signUpButton.isEnabled = true
                self.signUpButton.backgroundColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
                self.signUpButton.tintColor = UIColor.clear
            }
            self.classFilled = true
            self.classTextField.text = data2[int]
        }
        else {
            if self.classFilled{
                self.signUpButton.isEnabled = true
            }
            self.schoolFilled = true
            self.schoolTextField.text = data[int]
        }
        self.pickerView.isHidden = true
        self.doneButton.isHidden = true
        self.doneButton.isEnabled = false
    }
    
    @IBAction func cancelButtonTouched(_ sender: Any) {
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "initialSignUp") as! SignUpViewController
        dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var schoolTextField: UITextField!
    @IBAction func schoolTextFieldTouched(_ sender: Any) {
        self.selected = "school"
        self.schoolTextField.resignFirstResponder()
        self.pickerView.reloadAllComponents()
        self.pickerView.isHidden = false
        self.doneButton.isHidden = false
        self.doneButton.isEnabled = true
    }
    @IBAction func schoolTextFieldEditEnd(_ sender: Any) {
        self.pickerView.isHidden = true
        self.doneButton.isEnabled = false
        self.doneButton.isHidden = true
    }
    @IBOutlet weak var classTextField: UITextField!
    @IBAction func classTextFieldTouched(_ sender: Any) {
        self.selected = "class"
        self.pickerView.reloadAllComponents()
        self.classTextField.resignFirstResponder()
        self.pickerView.isHidden = false
        self.doneButton.isEnabled = true
        self.doneButton.isHidden = false
    }
    @IBAction func classTextViewEditEnd(_ sender: Any) {
        self.pickerView.isHidden = true
        self.doneButton.isEnabled = false
        self.doneButton.isHidden = true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.signUpButton.backgroundColor = UIColor.lightGray
        self.signUpButton.tintColor = UIColor.black
        self.signUpButton.isEnabled = false
        self.schoolTextField.backgroundColor = UIColor.clear
        self.classTextField.backgroundColor = UIColor.clear
        self.schoolTextField.textColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        self.classTextField.textColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        schoolTextField.attributedPlaceholder = NSAttributedString(string: schoolTextField.placeholder!, attributes: [.foregroundColor: UIColor.white])
        classTextField.attributedPlaceholder = NSAttributedString(string: classTextField.placeholder!, attributes: [.foregroundColor: UIColor.white])    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
