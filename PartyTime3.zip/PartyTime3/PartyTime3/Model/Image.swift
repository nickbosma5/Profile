//
//  File.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/29/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

class Image{
    var owner: String
    var location: String
    var id: String
    
    init(ownerString: String, locationString: String, idString: String) {
        owner = ownerString
        location = locationString
        id = idString
    }
}
