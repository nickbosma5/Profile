//
//  activeDealViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/27/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import Cosmos
import YPImagePicker
class activeDealViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UINavigationControllerDelegate  {
    
    
    @IBAction func cancelButtonTouched(_ sender: Any) {
        let refreshAlert = UIAlertController(title: "Cancel", message: "This deal will be abandoned", preferredStyle: UIAlertController.Style.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Continue", style: .default, handler: { (action: UIAlertAction!) in
            print("removing deal")
            let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
            let nextVC = storyboard.instantiateViewController(withIdentifier: "review") as! addReviewViewController
            nextVC.loanerID = self.loanerID
            nextVC.renterID = self.renterID
            nextVC.dealID = self.dealID
            nextVC.upcomingORongoing = "upcoming"
            self.present(nextVC, animated: true, completion: nil)
            let name = self.otherUserNameView.text ?? ""
            nextVC.howWouldYouTextView.text = "How would you rate " + name
            
            
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Back", style: .cancel, handler: { (action: UIAlertAction!) in
            refreshAlert.dismiss(animated: true, completion: nil)
        }))
        
        present(refreshAlert, animated: true, completion: nil)
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoStrings.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.damageCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! DamageCollectionViewCell
        
        if self.photoStrings.count != 0{
            let urlString = self.photoStrings[indexPath.row]
            let url = NSURL(string: urlString)!
            DispatchQueue.global(qos: .userInitiated).async {
                
                let imageData:NSData = NSData(contentsOf: url as URL)!
                
                
                DispatchQueue.main.async {
                    
                    let image = UIImage(data: imageData as Data)
                    cell.damagePhotoView.image = image
                    cell.damagePhotoView.contentMode = UIView.ContentMode.scaleAspectFill
                    cell.damagePhotoView.clipsToBounds = true
                    print("finished adding damage photo")
                }
            }
        }
        
        
        
        return cell
    }
    
    
    
    @IBOutlet var itemImageView: UIImageView!
    @IBOutlet var itemNameTextView: UITextView!
    @IBOutlet var addDamagePhoto: UIImageView!
    @IBOutlet var damageCollectionView: UICollectionView!
    
    @IBOutlet var startRentalButton: UIButton!
    @IBOutlet var renterReadyImageView: UIImageView!
    @IBOutlet var loanerReadyImageView: UIImageView!
    var dealID = String()
    var itemID = String()
    var loanerID = String()
    var renterID = String()
    var itemObject = NSDictionary()
    var dealObject = NSDictionary()
    var checkImage = UIImage()
    var tap1 = UITapGestureRecognizer()
    var tap2 = UITapGestureRecognizer()
    var tableViewController = DealsViewController()
    var photoStrings = [String]()
    
    @IBAction func notesButtonTouched(_ sender: Any) {
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "notes") as! AddNotesViewController
        nextVC.notes = self.itemObject["notes"] as? String ?? ""
        nextVC.itemID = self.itemID
        self.present(nextVC, animated: true, completion: nil)
        nextVC.notesTextView.text = nextVC.notes
    }
    
    
    override func viewDidLoad() {
        self.addDismissObserver()
        self.damageCollectionView.delegate = self
        self.damageCollectionView.dataSource = self
        if let user = Auth.auth().currentUser {
            self.addObserver()
            super.viewDidLoad()
            self.startRentalButton.isEnabled = false
            self.checkImage = UIImage(named: "checkMark")!
            let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
            let tapGestureRecognizer2 = UITapGestureRecognizer(target: self, action: #selector(imageTapped2(tapGestureRecognizer:)))
            let addPhotoTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addImageTapped(tapGestureRecognizer:)))
            self.addDamagePhoto.addGestureRecognizer(addPhotoTapGestureRecognizer)
            self.tap1 = tapGestureRecognizer
            self.tap2 = tapGestureRecognizer2
            self.addTapRecog()
            self.renterReadyImageView.isUserInteractionEnabled = true
            self.loanerReadyImageView.isUserInteractionEnabled = true
            
            
            loadData()
            loadOtherUserInfo()
        }
    }
    
    
    @objc func addImageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.renterReadyImageView.image = nil
        self.startRentalButton.isEnabled = false
        self.loanerReadyImageView.image = nil
        let imagePicker = YPImagePicker()
        imagePicker.delegate = self
        imagePicker.didFinishPicking { [unowned imagePicker] items, _ in
            if let photo = items.singlePhoto {
                //self.photos.append(photo.image)
                //print(self.photos.count)
                //self.photoCollectionView.reloadData()
                //self.imageView.image = photo.image
                //self.addImageButton.isEnabled = false
                //self.addImageButton.isHidden = true
                let random = self.randomString(num: 20)
                let imageRef = Storage.storage().reference().child("damagePhotos").child(random)
                var data = Data()
                data = photo.image.jpegData(compressionQuality: 1)!
                imagePicker.dismiss(animated: true, completion: nil)

                let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
                
                let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
                loadingIndicator.hidesWhenStopped = true
                loadingIndicator.style = UIActivityIndicatorView.Style.gray
                loadingIndicator.startAnimating();
                
                alert.view.addSubview(loadingIndicator)
                self.present(alert, animated: true, completion: nil)

                
                
                let uploadTask = imageRef.putData(data, metadata: nil) {(metadata, error) in
                    guard let metadata = metadata else{
                        print("error")
                        return
                    }
                    print("uploaded")
                    imageRef.downloadURL{ (url, error) in
                        guard let downloadURL = url else{
                            
                            print("error")
                            return
                        }
                        let URLstring = downloadURL.absoluteString
                        self.photoStrings.append(URLstring)
                        Database.database().reference().child("market").child(self.itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                            let itemObject = snapshot.value as? NSDictionary
                            var damagePhotos = itemObject?["damagePhotos"] as? [String] ?? []
                            damagePhotos.append(URLstring)
                            Database.database().reference().child("market").child(self.itemID).child("damagePhotos").setValue(damagePhotos)
                        })
                        alert.dismiss(animated: true, completion: nil)
                        self.damageCollectionView.reloadData()
                        
                    }
                }
            }
        }
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    func addDismissObserver(){
        Database.database().reference().child("deals").child("ongoing").observe(DataEventType.value, with: {(snapshot) in
            for deals in snapshot.children.allObjects as! [DataSnapshot]{
                if deals.key == self.dealID {
                    self.dismiss(animated: true, completion: nil)
                }
            }
        })
        Database.database().reference().child("deals").child("cancelled").observe(DataEventType.value, with: {(snapshot) in
            for deals in snapshot.children.allObjects as! [DataSnapshot]{
                if deals.key == self.dealID {
                    self.dismiss(animated: true, completion: nil)
                }
            }
        })
        
    }
    
    func addDamageObserver(){
        Database.database().reference().child("market").child(self.itemID).observe(DataEventType.value, with: {(snapshot) in
            let itemObject = snapshot.value as? NSDictionary
            print("something has changed")
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("loanerReady").setValue("no")
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("renterReady").setValue("no")
            self.damageCollectionView.reloadData()


        })
    }
    
    
    
    @IBOutlet var otherUserCosmosView: CosmosView!
    @IBOutlet var otherUserPhoneView: UITextView!
    @IBOutlet var otherUserNameView: UITextView!
    @IBOutlet var otherUserImageView: UIImageView!
    func addTapRecog(){
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let dealObject = snapshot.value as? NSDictionary
                let loanerID = dealObject?["loanerID"] as? String ?? ""
                let renterID = dealObject?["renterID"] as? String ?? ""
                if loanerID == user.uid {
                    self.loanerReadyImageView.addGestureRecognizer(self.tap1)
                }
                else if renterID == user.uid{
                    
                    self.renterReadyImageView.addGestureRecognizer(self.tap2)
                }
                else{
                    print("error")
                }
            })
        }
    }
    @IBAction func startRentalTouched(_ sender: Any) {
        Database.database().reference().child("users").child(self.loanerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            let userObject = snapshot.value as? NSDictionary
            var upcomingDeals = userObject?["upcomingDeals"] as? [String] ?? []
            var ongoingDeals = userObject?["ongoingDeals"] as? [String] ?? []
            
            for x in 0..<upcomingDeals.count{
                if upcomingDeals[x] == self.dealID{
                    upcomingDeals.remove(at: x)
                    ongoingDeals.append(self.dealID)
                    break
                }
            }
            print("Debug start _____")
            print(upcomingDeals)
            print(ongoingDeals)
            print(self.loanerID)
            Database.database().reference().child("users").child(self.loanerID).child("upcomingDeals").setValue(upcomingDeals)
            Database.database().reference().child("users").child(self.loanerID).child("ongoingDeals").setValue(ongoingDeals)
            
            
        })
        Database.database().reference().child("users").child(self.renterID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            let userObject = snapshot.value as? NSDictionary
            var upcomingDeals = userObject?["upcomingDeals"] as? [String] ?? []
            var ongoingDeals = userObject?["ongoingDeals"] as? [String] ?? []
            
            for x in 0..<upcomingDeals.count{
                if upcomingDeals[x] == self.dealID{
                    upcomingDeals.remove(at: x)
                    ongoingDeals.append(self.dealID)
                    break
                }
            }
            Database.database().reference().child("users").child(self.renterID).child("upcomingDeals").setValue(upcomingDeals)
            Database.database().reference().child("users").child(self.renterID).child("ongoingDeals").setValue(ongoingDeals)
            
            
        })
        
        Database.database().reference().child("deals").child("upcoming").child(self.dealID).removeValue()
        self.dealObject.setValue("no", forKey: "loanerReady")
        self.dealObject.setValue("no", forKey: "renterReady")
        Database.database().reference().child("deals").child("ongoing").child(self.dealID).setValue(self.dealObject)
        
        
        if self.tableViewController.completed_selected == true{
            self.tableViewController.completed_selected = false
        }
        else {
            self.tableViewController.completed_selected = true
        }
        self.tableViewController.tableView.reloadData()
        dismiss(animated: true, completion: nil)
        
    }
   /* @IBAction func conditionChanged(_ sender: Any) {
       print("condition changed")
        self.dealObject.setValue("no", forKey: "loanerReady")
        self.dealObject.setValue("no", forKey: "renterReady")
        Database.database().reference().child("deals").child("upcoming").child(self.dealID).setValue(dealObject)
        
        self.addObserver()
        
    }*/
    func loadOtherUserInfo(){
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let dealObject = snapshot.value as? NSDictionary
                let loanerID = dealObject?["loanerID"] as? String ?? ""
                let renterID = dealObject?["renterID"] as? String ?? ""
                var otherUserID = String()
                if user.uid == loanerID{
                    otherUserID = renterID
                }
                else{
                    otherUserID = loanerID
                }
                
                Database.database().reference().child("users").child(otherUserID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    let firstName = userObject?["FirstName"] as? String ?? ""
                    let lastName = userObject?["SecondName"] as? String ?? ""
                    let phone = userObject?["phoneNumber"] as? String ?? "error"
                    let photoURL = userObject?["profImage"] as? String ?? ""
                    if photoURL.count != 0{
                        print("success!")
                        let url = URL(string: photoURL)
                        print(url)
                        self.otherUserImageView.load(url: url!)
                        self.otherUserImageView.contentMode = .scaleAspectFill
                        self.otherUserImageView.clipsToBounds = true
                        self.otherUserImageView.layer.cornerRadius = self.otherUserImageView.frame.height/2
                    }
                    let rating = userObject?["rating"] as? Double ?? 0.0
                    self.otherUserCosmosView.rating = rating
                    self.otherUserPhoneView.text = phone
                    let firstNameStrip = firstName.trimmingCharacters(in: .whitespaces)
                    let lastNameStrip = lastName.trimmingCharacters(in: .whitespaces)
                    let fullName = firstNameStrip + " " + lastNameStrip
                    self.otherUserNameView.text = fullName
                })
            })
        }
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        if self.loanerReadyImageView.image == nil {
            self.loanerReadyImageView.image = self.checkImage
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("loanerReady").setValue("yes")
            if self.renterReadyImageView.image != nil {
                self.startRentalButton.isEnabled = true
            }
            
        }
        else{
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("loanerReady").setValue("no")
            self.loanerReadyImageView.image = nil
            self.startRentalButton.isEnabled = false
        }
    }
    @objc func imageTapped2(tapGestureRecognizer: UITapGestureRecognizer){
        if self.renterReadyImageView.image == nil{
            
            self.renterReadyImageView.image = self.checkImage
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("renterReady").setValue("yes")
            if self.loanerReadyImageView.image != nil{
                self.startRentalButton.isEnabled = true
            }
        }
        else{
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("renterReady").setValue("no")

            self.renterReadyImageView.image = nil
            self.startRentalButton.isEnabled = false
        }
    }
    func addObserver(){
        
        Database.database().reference().child("deals").child("upcoming").child(self.dealID).observe(DataEventType.value, with: {(snapshot) in
            let dealObject = snapshot.value as? NSDictionary
            let loanerReady = dealObject?["loanerReady"] as? String ?? ""
            let renterReady = dealObject?["renterReady"] as? String ?? ""
            
            self.dealObject = dealObject ?? [:]
            if renterReady == "yes" {
                
                self.renterReadyImageView.image = self.checkImage
                if self.loanerReadyImageView.image != nil{
                    self.startRentalButton.isEnabled = true
                }
            }
            else{
                
                self.renterReadyImageView.image = nil
                self.startRentalButton.isEnabled = false
            }
            if loanerReady == "yes" {
                self.loanerReadyImageView.image = self.checkImage
                if self.renterReadyImageView.image != nil {
                    self.startRentalButton.isEnabled = true
                }
                
            }
            else{
                self.loanerReadyImageView.image = nil
                self.startRentalButton.isEnabled = false
            }
            
        })
    }
    
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    func loadData(){
        Database.database().reference().child("deals").child("upcoming").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            let dealObject = snapshot.value as? NSDictionary
            let itemID = dealObject?["itemID"] as? String ?? ""
            self.itemID = itemID
            self.dealObject = dealObject ?? [:]
            self.loanerID = dealObject?["loanerID"] as? String ?? ""
            self.renterID = dealObject?["renterID"] as? String ?? ""
            self.addDamageObserver()
            
            Database.database().reference().child("market").child(self.itemID).observe(DataEventType.value, with: {(snapshot) in
                let itemObject = snapshot.value as? NSDictionary
                self.itemObject = itemObject ?? [:]
                
                //                Database.database().reference().child("market").child(self.itemID).setValue(self.itemObject)
                //                Database.database().reference().child("OFFmarket").child(self.itemID).removeValue()
                let itemName = itemObject?["name"] as? String ?? ""
                self.itemNameTextView.text = itemName
                let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                if downloadURL.count != 0 && self.itemImageView.image == nil{
                    let url = URL(string: downloadURL[0])
                    self.itemImageView.load(url: url!)
                }
                let damagePhotos = itemObject?["damagePhotos"] as? [String] ?? []
                self.photoStrings = damagePhotos
                self.damageCollectionView.reloadData()
            })
        })
    }
}

/*
 Database.database().reference().child("deals").child("active").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
 let dealObject = snapshot.value as? NSDictionary
 let itemID = dealObject?["itemID"] as? String ?? ""
 self.itemID = itemID
 self.dealObject = dealObject ?? [:]
 
 Database.database().reference().child("OFFmarket").child(self.itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
 let itemObject = snapshot.value as? NSDictionary
 self.itemObject = itemObject ?? [:]
 
 //                Database.database().reference().child("market").child(self.itemID).setValue(self.itemObject)
 //                Database.database().reference().child("OFFmarket").child(self.itemID).removeValue()
 })
 })
 */
