//
//  OfferViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/18/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase


class OfferViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var tableviewData = [cellData]()
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75.0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return tableviewData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableviewData[section].opened == true{
            return tableviewData[section].sectionData.count + 1

        }
        else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "offerTableCell") as? OfferItemTableViewCell else {return UITableViewCell()}
            if self.photoStrings.count != 0{
                let urlString = self.photoStrings[indexPath.section]
                let url = NSURL(string: urlString)!
                DispatchQueue.global(qos: .userInitiated).async {
                    
                    let imageData:NSData = NSData(contentsOf: url as URL)!
                    
                    
                    DispatchQueue.main.async {
                        
                        let image = UIImage(data: imageData as Data)
                        cell.itemImageView.image = image
                        cell.itemImageView.contentMode = UIView.ContentMode.scaleAspectFill
                        cell.itemImageView.clipsToBounds = true
                    }
                }
            }
            cell.itemNameTextView.text = tableviewData[indexPath.section].title
            
            return cell
            
        }
        else{
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "offerTableCell2") as?  OfferTableViewCell else {return UITableViewCell()}
            
            cell.textField.text = tableviewData[indexPath.section].sectionData[indexPath.row - 1]
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (tableviewData[indexPath.section].opened == true) {
            print(indexPath)
            if indexPath.row == 0 {
                tableviewData[indexPath.section].opened = false
                let sections = IndexSet.init(integer: indexPath.section)
                tableView.reloadSections(sections, with: .none)
            }
            else{
                print(indexPath)
                let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
                let nextVC = storyboard.instantiateViewController(withIdentifier: "reviewOffer") as! ReviewOfferViewController
                let itemString = self.items[indexPath.section]
                let offerString = self.dict2[itemString]![indexPath.row - 1]
                nextVC.offerID = offerString
                nextVC.tableView = self

                present(nextVC, animated: true, completion: nil)
                print("done")
                
            }
        }
        else if (tableviewData[indexPath.section].opened == false) {
            tableviewData[indexPath.section].opened = true
            let sections = IndexSet.init(integer: indexPath.section)
            tableView.reloadSections(sections, with: .none)
        }
        else{
            print(indexPath)
            print("click on offer")
        }

    }
    
    var offerIDs = [String]()
    var offers = [Offer]()
    var photoStrings = [String]()
    var offersTableData = [cellData]()
    var items = [String]()
    var dict: [String: [String]] = [:]
    var dict2: [String: [String]] = [:]
    
    @IBOutlet var navigationBar: UINavigationBar!
    @IBOutlet var offerTableView: UITableView!
    let tableViewController = OfferTableViewController()
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func addTouched(_ sender: Any) {
    }
    override func viewDidLoad() {
        print("loaded screen")
        super.viewDidLoad()
        //self.tableViewController.parentVC = self
        offerTableView.delegate = self
        offerTableView.dataSource = self
        //loadData()
        loadData2()
        offerTableView.reloadData()
    }
    
    
    func loadData2(){
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("users").child(user.uid).observe(DataEventType.value, with: {(snapshot) in
                let value = snapshot.value as? NSDictionary
                let offersReceived = value?["offersReceived"] as? [String] ?? []
                self.offerIDs = offersReceived
                //print("offerIDS:")
                //print(self.offerIDs)
            })
            
            Database.database().reference().child("offers").observe(DataEventType.value, with: {(snapshot) in
                self.offers.removeAll()
                for offer in snapshot.children.allObjects as! [DataSnapshot]{
                    if self.offerIDs.contains(offer.key){
                        let offerID = offer.key
                        let eventObject = offer.value as? [String: AnyObject]
                        let itemID = eventObject?["itemID"] as? String ?? ""
                        let startDate = eventObject?["startDate"] as? String ?? ""
                        let endDate = eventObject?["endDate"] as? String ?? ""
                        let location = eventObject?["location"] as? String ?? ""
                        let notes = eventObject?["notes"] as? String ?? ""
                        let renterID = eventObject?["renterID"] as? String ?? ""
                        var itemName = ""
                        Database.database().reference().child("market").child(itemID).observe(DataEventType.value, with: {(snapshot) in
                            let itemObject = snapshot.value as? [String: AnyObject]
                            let downloadURLs = itemObject?["downloadURL"] as? [String] ?? []
                            if downloadURLs.count != 0{
                                self.photoStrings.append(downloadURLs[0])
                            }
                            itemName = itemObject?["name"] as? String ?? ""
                            let offer = Offer(offerID: offerID, itemID: itemName, startDate: startDate, endDate: endDate, location: location, notes: notes, renterID: renterID, loanerID: user.uid)
                            self.offers.append(offer)
                            if self.items.contains(offer.itemID){
                            }
                            else{
                                self.items.append(offer.itemID)
                            }
                            print("offers:")
                            print(self.offers)
                            self.createTableData()
                            self.offerTableView.reloadData()
                        })
                        
                    }
                }
            })
        }
    }
    
        
    func createTableData(){
        self.tableviewData.removeAll()
        self.dict.removeAll()
        print(self.offers.count)
        for x in 0..<self.offers.count {
            print(x)
            if var list = dict[self.offers[x].itemID] {
                
                let string = (self.offers[x].startDate + " - " + self.offers[x].endDate)
                print("appended")
                list.append(string)
                dict[self.offers[x].itemID] = list
            }
            else{
                
                let string = (self.offers[x].startDate + " - " + self.offers[x].endDate)
                print("set")
                dict[self.offers[x].itemID] = [string]
                
            }
            if var list = dict2[self.offers[x].itemID]{
                let string = self.offers[x].offerID
                list.append(string)
                dict2[self.offers[x].itemID] = list
            }
            else{
                let string = self.offers[x].offerID
                dict2[self.offers[x].itemID] = [string]
            }
        }
        
        
        
        var numOffers = 0
        for (item, offers) in self.dict {
            tableviewData.append(cellData(opened: false, title: item, sectionData: offers))
            numOffers = numOffers + offers.count
        }
        print("tableview data:")
        print(tableviewData)
        self.navigationBar.topItem?.title = "Offers (" + String(numOffers) + ")"
        
    }
    func setString(date: Date) -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: date)
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = "MM/dd"
        let myStringafd = formatter.string(from: yourDate!)
        return myStringafd
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
