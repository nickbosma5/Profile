//
//  ViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/10/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class ViewController: UIViewController, UICollectionViewDelegate,
    UICollectionViewDataSource {
    
    @IBOutlet var navigationBar: UINavigationBar!
    @IBOutlet var offersButton: UIBarButtonItem!
    
    @IBOutlet var collectionView: UICollectionView!
    var photos = [UIImage]()
    var items = [NewItem]()
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "test", for: indexPath) as! MarketCollectionViewCell
        
        if self.items[indexPath.row].downloadURLs.count != 0{
            let urlString = self.items[indexPath.row].downloadURLs[0]
            let url = NSURL(string: urlString)!
            DispatchQueue.global(qos: .userInitiated).async {
                
                let imageData:NSData = NSData(contentsOf: url as URL)!
                
                
                DispatchQueue.main.async {
                    
                    let image = UIImage(data: imageData as Data)
                    cell.imageView.image = image
                    cell.imageView.contentMode = UIView.ContentMode.scaleAspectFill
                    cell.imageView.clipsToBounds = true
                }
            }
        }
       
        
        
        
        let str = String(self.items[indexPath.row].rentalRate)
        if str.contains("."){
            cell.rentalRateTextView.text = "$" + str + "0"
        }
        else{
            cell.rentalRateTextView.text = "$" + str + ".00"
        }
        cell.rentalRateTextView.text = "$" + String(self.items[indexPath.row].rentalRate) + "0"
        //view.layer.borderWidth = 5
        //view.layer.borderColor = UIColor.black.cgColor
        cell.textView.text = self.items[indexPath.row].ItemName
       
        return cell
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        load_data()
        collectionView.reloadData()
        
        
    }
   
    
    func load_data(){

        if let user = Auth.auth().currentUser {
            Database.database().reference().child("market").observe(DataEventType.value, with: {(snapshot) in
                self.items.removeAll()
                for items in snapshot.children.allObjects as! [DataSnapshot]{
                    let itemObject = items.value as? [String: AnyObject]
                    let downloadURLs = itemObject?["downloadURL"] as? [String] ?? []
                    
                    let name = itemObject?["name"] as? String ?? ""
                    let rentalRate = itemObject?["rentalRate"] as? Double ?? 0.00
                    let replacementFee = itemObject?["replacementFee"] as? Double ?? 0.00
                    let type = itemObject?["type"] as? String ?? ""
                    let tags = itemObject?["tags"] as? [String] ?? []
                    let colors = itemObject?["colors"] as? [String] ?? []
                    let descrip = itemObject?["description"] as? String ?? ""
                    let userID = itemObject?["loanerID"] as? String ?? ""
                    
                    
                    let itemID = items.key
                    
                    let newItem = NewItem(loanerID: userID, downloadURLs: downloadURLs, ItemName: name, category: type, rentalRate: rentalRate, replacementFee: replacementFee, itemID: itemID, tags: tags, colors: colors, descrip: descrip)
                    
                    
                    self.items.append(newItem)
                    Database.database().reference().child("users").child(user.uid).observe(DataEventType.value, with: {(snapshot) in
                        let value = snapshot.value as? NSDictionary
                        let offers = value?["offersReceived"] as? [String] ?? []
                        if offers.count != 0{
                            self.tabBarItem.badgeValue = String(offers.count)
                            
                        }
                        else{
                            self.tabBarItem.badgeValue = nil
                        }
                        let numOffers = offers.count
                        self.offersButton.title = "Offers(\(numOffers))"
                    })
                }
                self.collectionView.reloadData()
            })
            
            
        }
        
    }
    
    

}

extension ViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        // In this function is the code you must implement to your code project if you want to change size of Collection view
    
        return CGSize(width: (view.frame.width / 2) - 5, height: 250)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("hello")
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "itemController") as! MarketItem2ViewController
        nextVC.itemID = items[indexPath.row].itemID
        let cell = self.collectionView.cellForItem(at: indexPath) as! MarketCollectionViewCell
        present(nextVC, animated: true, completion: nil)
        nextVC.imageView.image = cell.imageView.image
        
    }
    
    
}
