//
//  ReviewOfferViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/25/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Cosmos
import Firebase



class ReviewOfferViewController: UIViewController {
    @IBOutlet var acceptButton: UIButton!
    @IBOutlet var declineButton: UIButton!
    @IBOutlet var notesTextView: UITextView!
    @IBOutlet var totalTextView: UITextView!
    @IBOutlet var datesTextView: UITextView!
    @IBOutlet var reviewsButton: UIButton!
    @IBOutlet var ratingView: CosmosView!
    @IBOutlet var nameTextView: UITextView!
    @IBOutlet var profileImageView: UIImageView!
    
    
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    var renterUpcomingDeals = [String]()
    var renterOffersPending = [String]()
    var itemDict = NSDictionary()
    var offerID = ""
    var itemID = String()
    var dailyRate = 0.0
    var loanerID = ""
    var renterID = String()
    var offersReceived = [String]()
    var upcomingDeals = [String]()
    var startDate = String()
    var endDate = String()
    var userItem = [String: Any]()
    var toRemove = [Int]()
    var tableView = OfferViewController()
    var datesUnavailable = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.profileImageView.clipsToBounds = true
        self.profileImageView.layer.cornerRadius = profileImageView.frame.height/2
        loadData()
    }
    
    func loadData(){
        Database.database().reference().child("offers").child(self.offerID).observeSingleEvent(of: .value, with: {(snapshot) in
            let value = snapshot.value as? NSDictionary
            let endDate = value?["endDate"] as? String ?? ""
            let startDate = value?["startDate"] as? String ?? ""
            let renterID = value?["renterID"] as? String ?? ""
            let notes = value?["notes"] as? String ?? ""
            let loanerID = value?["loanerID"] as? String ?? ""
            self.loanerID = loanerID
            self.renterID = renterID
            let itemID = value?["itemID"] as? String ?? ""
            self.datesTextView.text = "Dates: \(startDate) - \(endDate)"
            self.notesTextView.text = "Notes: \(notes)"
            self.nameTextView.text = renterID
            self.startDate = startDate
            self.endDate = endDate
            self.itemID = itemID
            self.renterID = renterID
            
            Database.database().reference().child("market").child(itemID).observeSingleEvent(of: .value, with: {(snapshot) in
                let value = snapshot.value as? NSDictionary
                self.itemDict = value ?? [:]
                self.dailyRate = value?["rentalRate"] as? Double ?? 0.0
                let datesUnavailable = value?["datesUnavailable"] as? [String] ?? []
                self.datesUnavailable = datesUnavailable
                let start = self.stringToDate(string: startDate)
                let end = self.stringToDate(string: endDate)
                let days = self.calcDays(date: start, date1: end)
                let total = self.dailyRate * Double(days)
                self.totalTextView.text = "\(days) days * $\(self.dailyRate)0 = $\(total)0"
            })
            
            Database.database().reference().child("users").child(renterID).observeSingleEvent(of: .value, with: {(snapshot) in
                let value = snapshot.value as? NSDictionary
                let firstName = value?["FirstName"] as? String ?? ""
                let lastName = value?["SecondName"] as? String ?? ""
                let rating = value?["rating"] as? Double ?? 0.0
                let photoString = value?["profImage"] as? String ?? ""
                if let url = URL(string: photoString){
                    self.profileImageView.load(url: url)
                }
                self.nameTextView.text = "\(firstName) \(lastName)"
                self.ratingView.rating = rating
                self.renterOffersPending = value?["offersPending"] as? [String] ?? []
                self.renterUpcomingDeals = value?["upcomingDeals"] as? [String] ?? []
            })
            Database.database().reference().child("users").child(loanerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let value = snapshot.value as? NSDictionary
                let offersReceived = value?["offersReceived"] as? [String] ?? []
                let upcomingDeals = value?["upcomingDeals"] as? [String] ?? []
                self.offersReceived = offersReceived
                self.upcomingDeals = upcomingDeals
            })
        })
    }
    
    @IBAction func acceptClicked(_ sender: Any) {
        self.renterUpcomingDeals.append(self.offerID)
        self.upcomingDeals.append(self.offerID)
        for x in 0..<self.offersReceived.count{
            if self.offersReceived[x] == self.offerID {
                self.offersReceived.remove(at: x)
                break
            }
        }
        for x in 0..<self.renterOffersPending.count{
            if self.renterOffersPending[x] == self.offerID{
                self.renterOffersPending.remove(at: x)
                break
            }
        }
        self.datesUnavailable.append("\(self.startDate) - \(self.endDate)")
        let newDeal = ["dealID": self.offerID, "startDate": self.startDate, "itemID": self.itemID, "rentalRate": self.dailyRate, "endDate": self.endDate, "loanerID": self.loanerID, "renterID": self.renterID] as [String: Any]
        Database.database().reference().child("offers").child(self.offerID).removeValue()
        Database.database().reference().child("deals").child("upcoming").child(self.offerID).setValue(newDeal)
        Database.database().reference().child("users").child(self.loanerID).child("upcomingDeals").setValue(self.upcomingDeals)
        Database.database().reference().child("users").child(self.loanerID).child("offersReceived").setValue(self.offersReceived)
        Database.database().reference().child("users").child(self.renterID).child("upcomingDeals").setValue(self.renterUpcomingDeals)
        Database.database().reference().child("users").child(self.renterID).child("offersPending").setValue(self.renterOffersPending)
        Database.database().reference().child("market").child(self.itemID).child("datesUnavailable").setValue(self.datesUnavailable)

        
        
        dismiss(animated: true, completion: nil)
        self.tableView.dismiss(animated: true, completion: nil)
    }
    @IBAction func declineTouched(_ sender: Any) {
        for x in 0..<self.offersReceived.count{
            if self.offersReceived[x] == self.offerID{
                self.offersReceived.remove(at: x)
                break
            }
        }
        Database.database().reference().child("users").child(self.loanerID).child("offersReceived").setValue(self.offersReceived)
        dismiss(animated: true, completion: nil)
    }
    
    
    
   /* func updateTextViews(){
        let calendar = Calendar.current
        
        // Replace the hour (time) of both dates with 00:00
        let date1 = calendar.startOfDay(for: self.startDate)
        let date2 = calendar.startOfDay(for: self.endDate)
        
        let components = calendar.dateComponents([.day], from: date1, to: date2).day!
        let total = Double(components) * self.dailyRate
        self.totalTextView.text = "Total: \(components) days * $\(self.dailyRate) = \(total)"
    }*/
    
}


