//
//  ClosetViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/17/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase

class ClosetViewController: UIViewController {
    
    var itemIDs = [String]()
    var items = [NewItem]()
    @IBAction func DoneTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        loadItems()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 130
    }
    
    
    func loadItems(){
        if Auth.auth().currentUser != nil {
            let userID = Auth.auth().currentUser?.uid
            Database.database().reference().child("users").observe(DataEventType.value, with: {(snapshot) in
                for events in snapshot.children.allObjects as! [DataSnapshot]{
                    let id = events.key
                    if id == userID {
                        let eventObject = events.value as? [String: AnyObject]
                        let closet = eventObject?["closet"] as? [String] ?? []
                        self.itemIDs = closet
                    }
                }
                Database.database().reference().child("market").observe(DataEventType.value, with: {(snapshot) in
                    self.items.removeAll()
                    for items in snapshot.children.allObjects as! [DataSnapshot]{
                        if self.itemIDs.contains(items.key){
                            let itemObject = items.value as? [String: AnyObject]
                            let downloadURLs = itemObject?["downloadURL"] as? [String] ?? []
                            
                            let name = itemObject?["name"] as? String ?? ""
                            let rentalRate = itemObject?["rentalRate"] as? Double ?? 0.00
                            let replacementFee = itemObject?["replacementFee"] as? Double ?? 0.00
                            let type = itemObject?["type"] as? String ?? ""
                            let tags = itemObject?["tags"] as? [String] ?? []
                            let colors = itemObject?["colors"] as? [String] ?? []
                            let descrip = itemObject?["description"] as? String ?? ""
                            
                            
                            let itemID = items.key
                            
                            let newItem = NewItem(loanerID: userID!, downloadURLs: downloadURLs, ItemName: name, category: type, rentalRate: rentalRate, replacementFee: replacementFee, itemID: itemID, tags: tags, colors: colors, descrip: descrip)
                            
                            
                            self.items.append(newItem)
                        }
                    }
                    self.tableView.reloadData()
                })
            })
        }
    }
    
    
    
}

extension ClosetViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "itemController") as! MarketItem2ViewController
        nextVC.itemID = items[indexPath.row].itemID
        present(nextVC, animated: true, completion: nil)
        nextVC.offerButton.isEnabled = false
        nextVC.offerButton.isHidden = true
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClosetCell", for: indexPath) as! ClosetTableViewCell
        
            cell.nameTextView.text = self.items[indexPath.row].ItemName
            cell.replacementFeeView.text = "$" + String(self.items[indexPath.row].replacementFee) + "0"
            cell.dailyRentalRateView.text = "$" + String(self.items[indexPath.row].rentalRate) + "0"
            
            let urlString = self.items[indexPath.row].downloadURLs[0]
            let url = NSURL(string: urlString)!
            /*DispatchQueue.global(qos: .userInitiated).async {
                
                let imageData:NSData = NSData(contentsOf: url as URL)!
                
                
                DispatchQueue.main.async {
                    
                    let image = UIImage(data: imageData as Data)
                    cell.ImageView.image = image
                    cell.ImageView.contentMode = UIView.ContentMode.scaleAspectFill
                    cell.ImageView.clipsToBounds = true
                }
            }*/
        
        return cell
    }
}
