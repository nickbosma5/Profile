//
//  ActiveDealTableViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class ActiveDealTableViewCell: UITableViewCell {
    @IBOutlet weak var startDateTextView: UITextView!
    @IBOutlet weak var itemNameTextView: UITextView!
    @IBOutlet weak var returnDateTextView: UITextView!
    @IBOutlet weak var returnTimeTextView: UITextView!
    @IBOutlet var itemImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
