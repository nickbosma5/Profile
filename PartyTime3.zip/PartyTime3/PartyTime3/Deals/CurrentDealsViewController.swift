//
//  CurrentDealsViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/23/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class CurrentDealsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad()
        
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.rowHeight = 130
        
    }
    
    
    
    
    
    
}

extension CurrentDealsViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let number = Int.random(in: 0 ..< 2)
        if number == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "DealsRentCell", for: indexPath)
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "DealsLoanCell", for: indexPath)
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print("hello")
    }
}
