//
//  NextViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/11/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {
    @IBOutlet weak var textView: UITextView!
    var num = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        let newText = String(num)
        textView.text = newText

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
