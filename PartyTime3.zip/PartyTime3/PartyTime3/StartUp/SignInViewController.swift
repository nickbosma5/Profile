//
//  SignInViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 1/14/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class SignInViewController: UIViewController, UIGestureRecognizerDelegate {
    @IBOutlet weak var PassTextField: UITextField!
    @IBOutlet weak var EmailTextField: UITextField!
    
    
    @IBAction func SignInTouched(_ sender: Any) {
    
        Auth.auth().signIn(withEmail: EmailTextField.text!, password: PassTextField.text!) { (user, error) in
            if error != nil {
                print(error!._code)
                self.handleError(error!)      // use the handleError method
                return
            }
            
            guard (user?.user) != nil else{
                print(error?.localizedDescription as Any)
                return
            }
            let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
            let profileVC = storyboard.instantiateViewController(withIdentifier: "tabBar")
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window!.rootViewController = profileVC
        }
    }
    
    func hideKeyboard(){
        let Tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        Tap.delegate = self 
        view.addGestureRecognizer(Tap)
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
        
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboard()
        EmailTextField.backgroundColor = UIColor.clear
        PassTextField.backgroundColor = UIColor.clear
        EmailTextField.textColor = UIColor.white
        PassTextField.textColor = UIColor.white
        
        EmailTextField.attributedPlaceholder = NSAttributedString(string: EmailTextField.placeholder!, attributes: [.foregroundColor: UIColor.lightGray])
        
        PassTextField.attributedPlaceholder = NSAttributedString(string: PassTextField.placeholder!, attributes: [.foregroundColor: UIColor.lightGray])
        

        
        /*let bottomLayer = CALayer()
        bottomLayer.frame = CGRect(x: -15, y: 20, width: 1000, height: 0.6)
        
        bottomLayer.backgroundColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor
        
        let bottomLayer1 = CALayer()
        bottomLayer1.frame = CGRect(x: -15, y: 20, width: 1000, height: 0.6)
        
        bottomLayer1.backgroundColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor
        
        EmailTextField.layer.addSublayer(bottomLayer)
        PassTextField.layer.addSublayer(bottomLayer1)*/
        // Do any additional setup after loading the view.
    }
    

    
}

extension AuthErrorCode {
    var errorMessage: String {
        switch self {
        case .emailAlreadyInUse:
            return "The email is already in use with another account"
        case .userNotFound:
            return "Account not found for the specified user. Please check and try again"
        case .userDisabled:
            return "Your account has been disabled. Please contact support."
        case .invalidEmail, .invalidSender, .invalidRecipientEmail:
            return "Please enter a valid email"
        case .networkError:
            return "Network error. Please try again."
        case .weakPassword:
            return "Your password is too weak. The password must be 6 characters long or more."
        case .wrongPassword:
            return "Your password is incorrect. Please try again or use 'Forgot password' to reset your password"
        default:
            return "Unknown error occurred"
        }
    }
}


extension UIViewController{
    func handleError(_ error: Error) {
        if let errorCode = AuthErrorCode(rawValue: error._code) {
            print(errorCode.errorMessage)
            let alert = UIAlertController(title: "Error", message: errorCode.errorMessage, preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            
            alert.addAction(okAction)
            
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    
}

