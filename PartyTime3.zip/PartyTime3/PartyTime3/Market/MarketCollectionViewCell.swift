//
//  MarketCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/7/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class MarketCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var rentalRateTextView: UITextView!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 5
    }

}
