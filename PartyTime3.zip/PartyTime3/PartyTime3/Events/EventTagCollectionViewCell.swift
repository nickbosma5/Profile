//
//  EventTagCollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/11/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class EventTagCollectionViewCell: UICollectionViewCell {
    @IBOutlet var textView: UITextView!
    
}
