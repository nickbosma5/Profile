//
//  Damage2CollectionViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/24/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class Damage2CollectionViewCell: UICollectionViewCell {
    @IBOutlet var photoImageView: UIImageView!
    
}
