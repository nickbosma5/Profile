//
//  PastDealTableViewCell.swift
//  PartyTime3
//
//  Created by Nick Bosma on 4/11/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit

class PastDealTableViewCell: UITableViewCell {

    @IBOutlet var itemImageView: UIImageView!
    @IBOutlet var nameTextView: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
