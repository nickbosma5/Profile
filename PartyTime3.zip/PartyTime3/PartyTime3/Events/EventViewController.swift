//
//  MarketItemViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 2/11/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
class MarketItemViewController: UIViewController {
    @IBOutlet weak var EventNameTextField: UITextView!
    @IBOutlet weak var DescriptionTextField: UITextView!
    @IBOutlet weak var dateTextField: UITextView!
    @IBAction func doneTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBOutlet var statusTextView: UITextView!
    
    @IBOutlet var invitePeopleButton: UIButton!
    @IBOutlet var declineButton: UIButton!
    @IBOutlet var maybeButton: UIButton!
    @IBOutlet var goingButton: UIButton!
    @IBOutlet var bottomButtons: UIStackView!
    @IBOutlet weak var loactionTextField: UITextView!
    var eventID = ""
    var accessibility = String()
    var status = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.invitePeopleButton.isEnabled = false
        if self.status == "owner"{
            self.invitePeopleButton.isEnabled = true
            self.bottomButtons.isHidden = true
            self.statusTextView.text = "Owner"
            self.statusTextView.textColor = UIColor(displayP3Red: 102/255, green: 252/255, blue: 241/255, alpha: 1)
        }
        else if self.status == "going"{
            self.statusTextView.text = "Going"
            self.statusTextView.textColor = UIColor.green
            
        }
        else if self.status == "invited"{
            self.statusTextView.text = "Invited"
            self.statusTextView.textColor = UIColor.yellow
        }
        
        Database.database().reference().child("events").observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            for events in snapshot.children.allObjects as! [DataSnapshot]{
                let id = events.key
                if id == self.eventID {
                    let eventObject = events.value as? [String: AnyObject]
                    let location = eventObject?["location"] as? String ?? ""
                    let date = eventObject?["date"] as? String ?? ""
                    let name = eventObject?["title"] as? String ?? ""
                    let descrip = eventObject?["description"] as? String ?? ""
                    let downloadURL = eventObject?["downloadURL"] as? String ?? ""
                    self.accessibility = eventObject?["accessibility"] as? String ?? ""
                    if downloadURL.count != 0{
                        self.eventImageView.image = nil
                        self.eventImageView.load(url: URL(string: downloadURL)!)
                    }
                    self.EventNameTextField.text = name
                    self.DescriptionTextField.text = descrip
                    self.loactionTextField.text = location
                    self.dateTextField.text = date
                }
            }
        })
        var frame = self.DescriptionTextField.frame
        frame.size.height = self.DescriptionTextField.contentSize.height
        self.DescriptionTextField.frame = frame

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goingTouched(_ sender: Any) {
        if let user = Auth.auth().currentUser{
            self.status = "going"
            self.statusTextView.text = "Going"
            self.statusTextView.textColor = UIColor.green
            Database.database().reference().child("events").child(self.eventID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let eventObject = snapshot.value as? NSDictionary
                var going = eventObject?["going"] as? [String] ?? []
                var invited = eventObject?["invited"] as? [String] ?? []
                if going.contains(user.uid){
                    return
                }
                else if invited.contains(user.uid) || self.accessibility == "public"{
                    for x in 0..<invited.count{
                        if invited[x] == user.uid{
                            invited.remove(at: x)
                            break
                        }
                    }
                    going.append(user.uid)
                }
                else {
                    print("error on push going button")
                }
                Database.database().reference().child("events").child(self.eventID).child("going").setValue(going)
                Database.database().reference().child("events").child(self.eventID).child("invited").setValue(invited)
                
            })
        }
        
    }
    
    @IBAction func inviteTouched(_ sender: Any) {
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "invitePeople") as! SearchPeopleViewController
        nextVC.eventID = self.eventID
        self.present(nextVC, animated: true, completion: nil)
    }
    
    @IBAction func maybeTouched(_ sender: Any) {
        if let user = Auth.auth().currentUser{
            self.status = "invited"
            self.statusTextView.text = "Invited"
            self.statusTextView.textColor = UIColor.yellow
            Database.database().reference().child("events").child(self.eventID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let eventObject = snapshot.value as? NSDictionary
                var going = eventObject?["going"] as? [String] ?? []
                var invited = eventObject?["invited"] as? [String] ?? []
                if invited.contains(user.uid){
                    return
                }
                else if going.contains(user.uid){
                    for x in 0..<going.count{
                        if going[x] == user.uid{
                            going.remove(at: x)
                            break
                        }
                    }
                    invited.append(user.uid)
                }
                else {
                    print("error on push maybe button")
                }
                Database.database().reference().child("events").child(self.eventID).child("going").setValue(going)
                Database.database().reference().child("events").child(self.eventID).child("invited").setValue(invited)
                
            })
        }
    }
    
    @IBAction func declineTouched(_ sender: Any) {
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("events").child(self.eventID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let eventObject = snapshot.value as? NSDictionary
                var going = eventObject?["going"] as? [String] ?? []
                var invited = eventObject?["invited"] as? [String] ?? []
                if going.contains(user.uid){
                    for x in 0..<going.count{
                        if going[x] == user.uid{
                            going.remove(at: x)
                            break
                        }
                    }
                }
                if invited.contains(user.uid){
                    for x in 0..<invited.count{
                        if invited[x] == user.uid{
                            invited.remove(at: x)
                            break
                        }
                    }
                }
                Database.database().reference().child("events").child(self.eventID).child("going").setValue(going)
                Database.database().reference().child("events").child(self.eventID).child("invited").setValue(invited)
                self.dismiss(animated: true, completion: nil)
                
            })
        }
    }
    @IBOutlet var eventImageView: UIImageView!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
