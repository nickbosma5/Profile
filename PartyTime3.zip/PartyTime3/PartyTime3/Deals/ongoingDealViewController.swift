//
//  ongoingDealViewController.swift
//  PartyTime3
//
//  Created by Nick Bosma on 3/28/19.
//  Copyright © 2019 Nick Bosma. All rights reserved.
//

import UIKit
import Firebase
import Cosmos
import YPImagePicker
class ongoingDealViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UINavigationControllerDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 75, height: 75)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.photoStrings.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.damagePhotoCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! Damage2CollectionViewCell
        
        if self.photoStrings.count != 0{
            let urlString = self.photoStrings[indexPath.row]
            let url = NSURL(string: urlString)!
            DispatchQueue.global(qos: .userInitiated).async {
                let imageData:NSData = NSData(contentsOf: url as URL)!
                DispatchQueue.main.async {
                    
                    let image = UIImage(data: imageData as Data)
                    cell.photoImageView.image = image
                    cell.photoImageView.contentMode = UIView.ContentMode.scaleAspectFill
                    cell.photoImageView.clipsToBounds = true
                }
            }
        }
        
        
        
        return cell
    }
    

    @IBOutlet var returnButton: UIButton!
    @IBOutlet var itemNameTextView: UITextView!
    @IBOutlet var itemImageView: UIImageView!
    @IBOutlet var otherUserReadyImageView: UIImageView!
    @IBOutlet var ratingView: CosmosView!
    @IBOutlet var otherUserPhotoView: UIImageView!
    
    @IBOutlet var phoneTextView: UITextView!
    @IBOutlet var otherNameTextView: UITextView!
    @IBOutlet var damagePhotoCollectionView: UICollectionView!
    @IBOutlet var addDamagePhoto: UIImageView!
    
    @IBAction func editNotesTouched(_ sender: Any) {
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "notes") as! AddNotesViewController
        nextVC.notes = self.itemObject["notes"] as? String ?? ""
        nextVC.itemID = self.itemID
        self.present(nextVC, animated: true, completion: nil)
        nextVC.notesTextView.text = nextVC.notes
    }
    
    @IBAction func cancelTouched(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func addDismissObserver(){
        Database.database().reference().child("deals").child("past").observe(DataEventType.value, with: {(snapshot) in
            for deal in snapshot.children.allObjects as! [DataSnapshot]{
                if deal.key == self.dealID{
                    print("deal found in completed")
                    self.dismiss(animated: true, completion: nil)
                }
            }
        })
    }
    
    @IBAction func returnButtonTouched(_ sender: Any) {
        Database.database().reference().child("deals").child("ongoing").child(self.dealID).removeValue()
        for x in 0..<self.loanerOngoingDeals.count{
            if self.loanerOngoingDeals[x] == self.dealID{
                self.loanerPastDeals.append(self.dealID)
                self.loanerOngoingDeals.remove(at: x)
                break
            }
        }
        for x in 0..<self.renterOngoingDeals.count{
            if self.renterOngoingDeals[x] == self.dealID{
                self.renterPastDeals.append(self.dealID)
                self.renterOngoingDeals.remove(at: x)
                break
            }
        }
        Database.database().reference().child("users").child(self.loanerID).child("ongoingDeals").setValue(self.loanerOngoingDeals)
        Database.database().reference().child("users").child(self.loanerID).child("pastDeals").setValue(self.loanerPastDeals)
        Database.database().reference().child("users").child(self.renterID).child("ongoingDeals").setValue(self.renterOngoingDeals)
        Database.database().reference().child("users").child(self.renterID).child("pastDeals").setValue(self.renterPastDeals)
            Database.database().reference().child("deals").child("past").child(self.offerID).setValue(self.dealObject)
        
        if self.tableViewController.completed_selected == true{
            self.tableViewController.completed_selected = false
        }
        else{
            self.tableViewController.completed_selected = true
        }
        self.tableViewController.tableView.reloadData()
        self.dismiss(animated: true, completion: nil)
        let storyboard: UIStoryboard = UIStoryboard(name: "TabBar", bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: "review") as! addReviewViewController
        nextVC.loanerID = self.loanerID
        nextVC.renterID = self.renterID
        nextVC.dealID = self.dealID
        nextVC.upcomingORongoing = "ongoing"
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window!.rootViewController = nextVC
        let name = self.otherNameTextView.text ?? ""
        nextVC.howWouldYouTextView.text = "How would you rate " + name
        
        
    }
    
    @IBOutlet var loanerReadyImageView: UIImageView!
    var offerID = String()
    var itemID = String()
    var dealID = String()
    var loanerID = String()
    var renterID = String()
    var dealObject = NSDictionary()
    var itemObject = NSDictionary()
    var checkImage = UIImage()
    var loanerOngoingDeals = [String]()
    var renterOngoingDeals = [String]()
    var loanerPastDeals = [String]()
    var renterPastDeals = [String]()
    var tableViewController = DealsViewController()
    var tap1 = UITapGestureRecognizer()
    var tap2 = UITapGestureRecognizer()
    var photoStrings = [String]()
    
    override func viewDidLoad() {
        addDismissObserver()
        super.viewDidLoad()
        self.damagePhotoCollectionView.delegate = self
        self.damagePhotoCollectionView.dataSource = self
        self.returnButton.isEnabled = false
        loadData()
        loadData2()
        
        addObserver()
        addTapG()
        self.checkImage = UIImage(named: "checkMark")!
        self.tap1 = UITapGestureRecognizer(target: self, action:#selector(handleTap(tapGestureRecognizer:)))
        self.tap2 = UITapGestureRecognizer(target: self, action:#selector(handleTap2(tapGestureRecognizer:)))
        let addPhotoTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addImageTapped(tapGestureRecognizer:)))
        self.addDamagePhoto.addGestureRecognizer(addPhotoTapGestureRecognizer)
        
        // Do any additional setup after loading the view.
        
    }
    
    @objc func addImageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.otherUserReadyImageView.image = nil
        self.returnButton.isEnabled = false
        self.loanerReadyImageView.image = nil
        let imagePicker = YPImagePicker()
        imagePicker.delegate = self
        imagePicker.didFinishPicking { [unowned imagePicker] items, _ in
            if let photo = items.singlePhoto {
                //self.photos.append(photo.image)
                //print(self.photos.count)
                //self.photoCollectionView.reloadData()
                //self.imageView.image = photo.image
                //self.addImageButton.isEnabled = false
                //self.addImageButton.isHidden = true
                let random = self.randomString(num: 20)
                let imageRef = Storage.storage().reference().child("damagePhotos").child(random)
                var data = Data()
                data = photo.image.jpegData(compressionQuality: 1)!
                imagePicker.dismiss(animated: true, completion: nil)
                
                let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
                
                let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
                loadingIndicator.hidesWhenStopped = true
                loadingIndicator.style = UIActivityIndicatorView.Style.gray
                loadingIndicator.startAnimating();
                
                alert.view.addSubview(loadingIndicator)
                self.present(alert, animated: true, completion: nil)
                
                
                
                let uploadTask = imageRef.putData(data, metadata: nil) {(metadata, error) in
                    guard let metadata = metadata else{
                        print("error")
                        return
                    }
                    print("uploaded")
                    imageRef.downloadURL{ (url, error) in
                        guard let downloadURL = url else{
                            
                            print("error")
                            return
                        }
                        let URLstring = downloadURL.absoluteString
                        self.photoStrings.append(URLstring)
                        Database.database().reference().child("market").child(self.itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                            let itemObject = snapshot.value as? NSDictionary
                            var damagePhotos = itemObject?["damagePhotos"] as? [String] ?? []
                            damagePhotos.append(URLstring)
                            Database.database().reference().child("market").child(self.itemID).child("damagePhotos").setValue(damagePhotos)
                        })
                        alert.dismiss(animated: true, completion: nil)
                        self.damagePhotoCollectionView.reloadData()
                        print("debug")
                        print(self.photoStrings.count)
                    }
                }
            }
        }
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    @objc func handleTap(tapGestureRecognizer: UITapGestureRecognizer){
        print("hello")
        if self.loanerReadyImageView.image == nil {
            Database.database().reference().child("deals").child("ongoing").child(self.offerID).child("loanerReady").setValue("yes")
            self.loanerReadyImageView.image = self.checkImage
            if self.otherUserReadyImageView.image != nil{
                self.returnButton.isEnabled = true
            }
        }
        else {
            Database.database().reference().child("deals").child("ongoing").child(self.offerID).child("loanerReady").setValue("no")
            self.loanerReadyImageView.image = nil
            self.returnButton.isEnabled = false
        }
    }
    @objc func handleTap2(tapGestureRecognizer: UITapGestureRecognizer){
        print("hello")
        if self.otherUserReadyImageView.image == nil {
            Database.database().reference().child("deals").child("ongoing").child(self.offerID).child("renterReady").setValue("yes")
            self.otherUserReadyImageView.image = self.checkImage
            if self.loanerReadyImageView.image != nil{
                self.returnButton.isEnabled = true
            }
        }
        else {
            Database.database().reference().child("deals").child("ongoing").child(self.offerID).child("renterReady").setValue("no")
            self.otherUserReadyImageView.image = nil
            self.returnButton.isEnabled = false
        }

    }

    func loadOtherUserInfo(){
        if let user = Auth.auth().currentUser{
            print(1)
            Database.database().reference().child("deals").child("ongoing").child(self.dealID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let dealObject = snapshot.value as? NSDictionary
                let loanerID = dealObject?["loanerID"] as? String ?? ""
                let renterID = dealObject?["renterID"] as? String ?? ""
                var otherUserID = String()
                if user.uid == loanerID{
                    otherUserID = renterID
                }
                else{
                    otherUserID = loanerID
                }
                print(2)
                Database.database().reference().child("users").child(otherUserID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    let firstName = userObject?["FirstName"] as? String ?? ""
                    let lastName = userObject?["SecondName"] as? String ?? ""
                    let phone = userObject?["phoneNumber"] as? String ?? "error"
                    let photoURL = userObject?["profImage"] as? String ?? ""
                    if photoURL.count != 0{
                        print("success!")
                        let url = URL(string: photoURL)
                        print(url)
                        self.otherUserPhotoView.load(url: url!)
                        self.otherUserPhotoView.contentMode = .scaleAspectFill
                        self.otherUserPhotoView.clipsToBounds = true
                        self.otherUserPhotoView.layer.cornerRadius = self.otherUserPhotoView.frame.height/2
                    }
                    let rating = userObject?["rating"] as? Double ?? 0.0
                    self.ratingView.rating = rating
                    self.ratingView.text = phone
                    let firstNameStrip = firstName.trimmingCharacters(in: .whitespaces)
                    let lastNameStrip = lastName.trimmingCharacters(in: .whitespaces)
                    let fullName = firstNameStrip + " " + lastNameStrip
                    self.otherNameTextView.text = fullName
                })
            })
        }
    }
    
    func addObserver(){
        Database.database().reference().child("deals").child("ongoing").child(self.offerID).observe(DataEventType.value, with: {(snapshot) in
            let dealObject = snapshot.value as? NSDictionary
            let loanerReady = dealObject?["loanerReady"] as? String ?? ""
            let renterReady = dealObject?["renterReady"] as? String ?? ""
            self.dealObject = dealObject ?? [:]
            if renterReady == "yes"{
                self.otherUserReadyImageView.image = self.checkImage
                if self.loanerReadyImageView.image != nil{
                    self.returnButton.isEnabled = true
                }
            }
            else{
                self.otherUserReadyImageView.image = nil
                self.returnButton.isEnabled = false
            }
            if loanerReady == "yes"{
                self.loanerReadyImageView.image = self.checkImage
                if self.otherUserReadyImageView.image != nil{
                    self.returnButton.isEnabled = true
                }
            }
            else{
                self.loanerReadyImageView.image = nil
                self.returnButton.isEnabled = false
            }
        })
    }
    
    func addTapG(){
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("deals").child("ongoing").child(self.offerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let dealObject = snapshot.value as? NSDictionary
                let loanerID = dealObject?["loanerID"] as? String ?? ""
                let renterID = dealObject?["renterID"] as? String ?? ""
                if user.uid == loanerID{
                    self.loanerReadyImageView.addGestureRecognizer(self.tap1)
                }
                else{
                    self.otherUserReadyImageView.addGestureRecognizer(self.tap2)
                }
            })
        }
    }
    
    func addDamageObserver(){
        Database.database().reference().child("market").child(self.itemID).observe(DataEventType.value, with: {(snapshot) in
            let itemObject = snapshot.value as? NSDictionary
            print("something has changed")
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("loanerReady").setValue("no")
            Database.database().reference().child("deals").child("upcoming").child(self.dealID).child("renterReady").setValue("no")
            self.damagePhotoCollectionView.reloadData()
            
            
        })
    }
    
    func loadData(){
        if let user = Auth.auth().currentUser{
            Database.database().reference().child("deals").child("ongoing").child(self.offerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                let dealObject = snapshot.value as? NSDictionary
                self.dealObject = dealObject!
                self.dealID = snapshot.key
                self.loadOtherUserInfo()
                let itemID = self.dealObject["itemID"] as? String ?? ""
                self.itemID = itemID
                self.loanerID = dealObject?["loanerID"] as? String ?? ""
                self.renterID = dealObject?["renterID"] as? String ?? ""
                self.itemNameTextView.text = self.itemID
                Database.database().reference().child("users").child(self.loanerID).observe(DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    self.loanerPastDeals = userObject?["pastDeals"] as? [String] ?? []
                    self.loanerOngoingDeals = userObject?["ongoingDeals"] as? [String] ?? []
                })
                Database.database().reference().child("users").child(self.renterID).observe(DataEventType.value, with: {(snapshot) in
                    let userObject = snapshot.value as? NSDictionary
                    self.renterPastDeals = userObject?["pastDeals"] as? [String] ?? []
                    self.renterOngoingDeals = userObject?["ongoingDeals"] as? [String] ?? []
                })
                Database.database().reference().child("market").child(self.itemID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
                    let itemObject = snapshot.value as? NSDictionary
                    self.itemObject = itemObject!
                    self.itemNameTextView.text = itemObject?["name"] as? String ?? "error"
                    let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                    if downloadURL.count != 0{
                        let url = URL(string: downloadURL[0])
                        self.itemImageView.load(url: url!)
                    }
                })
                
            })
        }
        
        
    }
    func loadData2(){
        Database.database().reference().child("deals").child("ongoing").child(self.offerID).observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            let dealObject = snapshot.value as? NSDictionary
            let itemID = dealObject?["itemID"] as? String ?? ""
            self.itemID = itemID
            self.dealObject = dealObject ?? [:]
            self.loanerID = dealObject?["loanerID"] as? String ?? ""
            self.renterID = dealObject?["renterID"] as? String ?? ""
            self.addDamageObserver()
            
            Database.database().reference().child("market").child(self.itemID).observe(DataEventType.value, with: {(snapshot) in
                let itemObject = snapshot.value as? NSDictionary
                self.itemObject = itemObject ?? [:]
                
                //                Database.database().reference().child("market").child(self.itemID).setValue(self.itemObject)
                //                Database.database().reference().child("OFFmarket").child(self.itemID).removeValue()
                let itemName = itemObject?["name"] as? String ?? ""
                self.itemNameTextView.text = itemName
                let downloadURL = itemObject?["downloadURL"] as? [String] ?? []
                if downloadURL.count != 0 && self.itemImageView.image == nil{
                    let url = URL(string: downloadURL[0])
                    self.itemImageView.load(url: url!)
                }
                let damagePhotos = itemObject?["damagePhotos"] as? [String] ?? []
                self.photoStrings = damagePhotos
                self.damagePhotoCollectionView.reloadData()
            })
        })
    }
    
    
}


